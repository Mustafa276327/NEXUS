# ⚡ NEXUS v6.0

Otonom kapalı döngü AI sistemi.

## Kurulum
```bash
bash kur.sh
nano .env
```

## Başlatma
```bash
python panel.py
```

## Özellikler
- 20 hazır bot (Web x5, Kod x5, Haber x5, Analiz x5)
- VeriDuzenleyici (merkezi yazıcı)
- Kategori bazlı öğrenme (5 kategori)
- Zincir öğrenme (AI ilişkili konu önerir)
- Telegram bot (10dk auto-reply)
- Web panel (authenticated)
