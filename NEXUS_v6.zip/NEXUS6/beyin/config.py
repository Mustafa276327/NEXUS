"""NEXUS v6 - Konfigürasyon"""
from __future__ import annotations
import os, sys
from pathlib import Path

def _env_yukle():
    env = Path(__file__).parent.parent / ".env"
    if env.exists():
        for s in env.read_text(encoding="utf-8").splitlines():
            s = s.strip()
            if s and not s.startswith("#") and "=" in s:
                k, v = s.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())
_env_yukle()

BASE_DIR     = Path(os.environ.get("NEXUS_BASE", str(Path(__file__).parent.parent)))
BEYIN_DIR    = BASE_DIR / "beyin"
ZEKA_DIR     = BASE_DIR / "zeka"
TELEGRAM_DIR = BASE_DIR / "telegram"
SISTEM_DIR   = BASE_DIR / "sistem"
PANEL_DIR    = BASE_DIR / "panel"
BOTLAR_DIR   = BASE_DIR / "botlar"
DEPO_DIR     = BASE_DIR / "depo"
KAYIT_DIR    = BASE_DIR / "kayit"
YEDEK_DIR    = BASE_DIR / "yedek"
DOCS_DIR     = BASE_DIR / "docs"

BOT_AKTIF    = BOTLAR_DIR / "aktif"
BOT_ARSIV    = BOTLAR_DIR / "arsiv"
BOT_FAIL     = BOTLAR_DIR / "fail"
BOT_SANDBOX  = BOTLAR_DIR / "sandbox"

DB_PATH      = DEPO_DIR / "nexus.db"
FEAT_PATH    = DEPO_DIR / "features.json"
QUEUE_PATH   = DEPO_DIR / "queue.db"

# API
OPENROUTER_API_KEY = os.environ.get("OPENROUTER_API_KEY", "")
OPENROUTER_URL     = "https://openrouter.ai/api/v1/chat/completions"
OPENROUTER_MODEL   = os.environ.get("OPENROUTER_MODEL", "openrouter/auto")
AI_TIMEOUT         = 120

# Telegram
TELEGRAM_TOKEN   = os.environ.get("TELEGRAM_TOKEN",   "")
TELEGRAM_CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID", "")

# GitHub
GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN", "")
GITHUB_USER  = os.environ.get("GITHUB_USER",  "")
GITHUB_REPO  = os.environ.get("GITHUB_REPO",  "nexus-yedek")

# Sistem limitleri
CPU_KRITIK       = 65
BATARYA_KRITIK   = 30   # Sadece %30 ve %15'te sor
DONGU_SURESI     = 8    # Hızlandırıldı (eski: 15)
WEB_PORT         = int(os.environ.get("NEXUS_PORT", "8080"))
WEB_SIFRE        = os.environ.get("WEB_SIFRE", "nexus123")
VERSIYON         = "6.0.0"

# Öğrenme kategorileri ve başlangıç konuları
KATEGORILER = {
    "Yazilim": {
        "baslangic": ["Python temel", "HTML CSS", "JavaScript", "Git versiyon kontrol",
                      "Linux komutları", "bash scripting", "API kavramı", "JSON"],
        "agirlik": 30
    },
    "Kultur": {
        "baslangic": ["Türk edebiyatı", "dünya tarihi", "mitoloji", "sanat akımları",
                      "müzik teorisi", "sinema tarihi", "felsefe temelleri"],
        "agirlik": 15
    },
    "Bilim": {
        "baslangic": ["fizik yasaları", "kimya elementleri", "biyoloji hücre",
                      "astronomi gezegenler", "matematik temelleri", "istatistik"],
        "agirlik": 20
    },
    "Teknoloji": {
        "baslangic": ["yapay zeka temelleri", "makine öğrenimi", "blockchain",
                      "siber güvenlik", "bulut bilişim", "IoT nesnelerin interneti"],
        "agirlik": 25
    },
    "Ekonomi": {
        "baslangic": ["mikro ekonomi", "borsa temelleri", "kripto para", "girişimcilik",
                      "pazarlama", "finans yönetimi"],
        "agirlik": 10
    },
}

RUTBELER = {
    "yeni":      {"puan": 0,    "bot_uretebilir": False},
    "acemi":     {"puan": 100,  "bot_uretebilir": False},
    "yardimci":  {"puan": 300,  "bot_uretebilir": False},
    "uzman":     {"puan": 600,  "bot_uretebilir": True},
    "usta":      {"puan": 1000, "bot_uretebilir": True},
    "profesor":  {"puan": 2000, "bot_uretebilir": True},
    "superzeka": {"puan": 5000, "bot_uretebilir": True},
    "anayz":     {"puan": 9999, "bot_uretebilir": True},
}

def dogrula():
    hatalar = []
    if not OPENROUTER_API_KEY:
        hatalar.append("OPENROUTER_API_KEY eksik")
    if not (1 <= WEB_PORT <= 65535):
        hatalar.append(f"NEXUS_PORT geçersiz: {WEB_PORT}")
    if hatalar:
        for h in hatalar:
            print(f"[CONFIG ❌] {h}", file=sys.stderr)
        raise RuntimeError(f"Kritik config hatası: {', '.join(hatalar)}")
    if not TELEGRAM_TOKEN:
        print("[CONFIG ⚠️] TELEGRAM_TOKEN eksik — Telegram çalışmaz", file=sys.stderr)

def klasorleri_olustur():
    for d in [BEYIN_DIR, ZEKA_DIR, TELEGRAM_DIR, SISTEM_DIR, PANEL_DIR,
              DEPO_DIR, KAYIT_DIR, YEDEK_DIR, DOCS_DIR,
              BOT_AKTIF, BOT_ARSIV, BOT_FAIL, BOT_SANDBOX,
              BOTLAR_DIR / "web_tarama",
              BOTLAR_DIR / "yazilim",
              BOTLAR_DIR / "veri",
              BOTLAR_DIR / "haber",
              BOTLAR_DIR / "analiz"]:
        d.mkdir(parents=True, exist_ok=True)
