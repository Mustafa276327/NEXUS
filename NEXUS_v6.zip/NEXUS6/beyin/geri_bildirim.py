"""NEXUS v6 - Geri Bildirim (düzeltilmiş SQL sorguları)"""
from __future__ import annotations
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Tuple
from beyin.config import DEPO_DIR
from beyin.logger import bilgi, hata

def degerlendir(gorev: str, kod: str, cikti: str) -> Tuple[float, str]:
    try:
        from beyin.ai import sor
        c = sor(
            f"Görev: {gorev[:150]}\nKod: {kod[:150]}\nÇıktı: {cikti[:150]}\n\n"
            "0-10 puan ver. SADECE şu format:\nPUAN: 7\nYORUM: kısa açıklama",
            sicaklik=0.1, maks_sure=45
        )
        if c:
            puan, yorum = 5.0, c
            for s in c.strip().splitlines():
                if s.startswith("PUAN:"):
                    try: puan = max(0.0, min(10.0, float(s.replace("PUAN:","").strip())))
                    except Exception: pass
                elif s.startswith("YORUM:"):
                    yorum = s.replace("YORUM:","").strip()
            _kaydet(gorev, puan, yorum)
            return puan, yorum
    except Exception as e:
        hata("geri_bildirim", f"Değerlendirme: {e}")
    puan = 6.0 if cikti and len(cikti) > 10 else 3.0
    yorum = "Kod çalıştı" if puan > 5 else "Kısmi başarı"
    _kaydet(gorev, puan, yorum)
    return puan, yorum

def _kaydet(gorev: str, puan: float, yorum: str):
    try:
        con = sqlite3.connect(str(DEPO_DIR/"nexus.db"), timeout=10)
        con.execute("PRAGMA journal_mode=WAL")
        con.execute("INSERT INTO geri_bildirimler(gorev,puan,yorum,tarih) VALUES(?,?,?,?)",
                    (gorev[:200], puan, yorum[:300], datetime.now().isoformat()))
        con.commit(); con.close()
    except Exception as e:
        hata("geri_bildirim", f"Kayıt: {e}")

def ortalama_puan() -> float:
    """Düzeltilmiş — son 20 kaydın ortalaması"""
    try:
        con = sqlite3.connect(str(DEPO_DIR/"nexus.db"), timeout=5)
        r = con.execute(
            "SELECT AVG(puan) FROM geri_bildirimler "
            "WHERE id IN (SELECT id FROM geri_bildirimler ORDER BY id DESC LIMIT 20)"
        ).fetchone()
        con.close()
        return round(r[0] or 0, 2)
    except Exception: return 0.0

def gelisim_trendi() -> str:
    """Düzeltilmiş — son 5 vs önceki 5"""
    try:
        con = sqlite3.connect(str(DEPO_DIR/"nexus.db"), timeout=5)
        ids = [r[0] for r in con.execute(
            "SELECT id FROM geri_bildirimler ORDER BY id DESC LIMIT 10"
        ).fetchall()]
        if len(ids) < 2:
            con.close(); return "Veri yok"
        son5_ids  = ids[:5]
        once5_ids = ids[5:]
        son5  = con.execute(f"SELECT AVG(puan) FROM geri_bildirimler WHERE id IN ({','.join(map(str,son5_ids))})").fetchone()[0] or 0
        once5 = con.execute(f"SELECT AVG(puan) FROM geri_bildirimler WHERE id IN ({','.join(map(str,once5_ids))})").fetchone()[0] or 0 if once5_ids else son5
        con.close()
        if son5 > once5 + 0.5:   return f"📈 Gelişiyor ({once5:.1f}→{son5:.1f})"
        if son5 < once5 - 0.5:   return f"📉 Gerileme ({once5:.1f}→{son5:.1f})"
        return f"➡️ Stabil ({son5:.1f})"
    except Exception: return "Veri yok"
