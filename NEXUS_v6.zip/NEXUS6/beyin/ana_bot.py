#!/usr/bin/env python3
"""
NEXUS v6 - Ana Bot
- Hızlandırıldı (döngü 8sn, öğrenme 60sn, görev 180sn)
- İç ses prompt düzeltildi
- 20 hazır bot
- VeriDuzenleyici entegreli
- Kategori bazlı öğrenme
"""
from __future__ import annotations
import atexit, fcntl, os, sys, threading, time
from datetime import datetime
from pathlib import Path

# PID kilidi
_KILIT = Path.home() / ".nexus_v6.lock"
_kilit_fd = None

def _pid_kontrol():
    global _kilit_fd
    try:
        _kilit_fd = open(str(_KILIT), "w")
        fcntl.flock(_kilit_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        _kilit_fd.write(str(os.getpid())); _kilit_fd.flush()
    except (IOError, OSError):
        print("⚠️  NEXUS v6 zaten çalışıyor."); sys.exit(0)

    @atexit.register
    def _birak():
        try:
            fcntl.flock(_kilit_fd, fcntl.LOCK_UN)
            _kilit_fd.close(); _KILIT.unlink(missing_ok=True)
        except Exception: pass

_pid_kontrol()

BASE = Path(__file__).parent.parent
sys.path.insert(0, str(BASE))
os.environ.setdefault("NEXUS_BASE", str(BASE))

from beyin.config import DONGU_SURESI, CPU_KRITIK, BATARYA_KRITIK, VERSIYON, DOCS_DIR, klasorleri_olustur, dogrula
from beyin.logger import bilgi, hata, uyari, basari, anayz as log_anayz
from beyin.veritabani import tablolari_olustur, sorgu

_sayac = 0
_sayac_lock = threading.Lock()
_baslangic = datetime.now()
_hafif_mod = False
_sarj_uyarildi: set = set()


# ── BAŞLATMA ─────────────────────────────────────────────
def _adim1():
    dogrula(); klasorleri_olustur()
    bilgi("ana_bot", "✅ [1/7] Config & klasörler")

def _adim2():
    tablolari_olustur()
    bilgi("ana_bot", "✅ [2/7] Veritabanı")

def _adim3():
    from beyin.ai import sor
    c = sor("Merhaba, sistem testi.", maks_sure=20)
    if c: bilgi("ana_bot", "✅ [3/7] OpenRouter API")
    else: uyari("ana_bot", "⚠️ [3/7] OpenRouter bağlanamadı — devam")

def _adim4():
    from zeka.anayz import anayz_al
    az = anayz_al()
    log_anayz("ana_bot", f"✅ [4/7] AnaYZ: {az.isim}")
    if not (Path(DOCS_DIR)/"anayasa.json").exists():
        try: az.anayasa_yaz()
        except Exception as e: uyari("ana_bot", f"Anayasa: {e}")

def _adim5():
    try:
        from telegram.bot import arkaplanda_baslat
        arkaplanda_baslat()
        bilgi("ana_bot", "✅ [5/7] Telegram")
    except Exception as e: uyari("ana_bot", f"⚠️ [5/7] Telegram: {e}")

def _adim6():
    # VeriDuzenleyici (tek merkezi yazıcı)
    from beyin.veri_duzenleyici import baslat as vd_baslat
    vd_baslat()
    bilgi("ana_bot", "✅ [6/7] VeriDuzenleyici")

def _adim7():
    # Hazır botlar (20 bot)
    from beyin.hazir_botlar import hepsini_baslat
    hepsini_baslat()
    # Dinamik bot izleme
    from beyin.bot_yonetici import izlemeyi_baslat
    izlemeyi_baslat()
    bilgi("ana_bot", "✅ [7/7] Botlar başlatıldı")

def sistem_hazirla():
    print(f"\033[96m╔══════════════════════════════════════════════╗")
    print(f"║  ⚡ N E X U S  v{VERSIYON}  —  ANA BOT       ║")
    print(f"║  Kapalı Döngü | 20 Bot | Kategori Öğrenme   ║")
    print(f"╚══════════════════════════════════════════════╝\033[0m")
    _adim1(); _adim2(); _adim3(); _adim4()
    _adim5(); _adim6(); _adim7()
    bilgi("ana_bot", "🚀 NEXUS v6 hazır! Tüm sistemler aktif.")

@atexit.register
def _kapat():
    bilgi("ana_bot", "⏹️ Kapatılıyor...")
    try:
        from telegram.bot import durdur; durdur()
    except Exception: pass
    from beyin.veri_duzenleyici import durdur as vd_durdur
    vd_durdur()
    bilgi("ana_bot", "👋 NEXUS v6 kapandı")


# ── TELEFON + ŞARJ KONTROLÜ ──────────────────────────────
def _telefon_kontrol():
    global _hafif_mod, _sarj_uyarildi
    try:
        from sistem.telefon import sistem_durumu
        d = sistem_durumu()
        pil = d["pil_yuzde"]; sarj = d["sarj"]

        # Şarj oluyor → sıfırla
        if sarj:
            _sarj_uyarildi.discard(30); _sarj_uyarildi.discard(15)

        # Sadece %30 ve %15'te bir kez sor
        if not sarj:
            for esik in [30, 15]:
                if pil <= esik and esik not in _sarj_uyarildi:
                    _sarj_uyarildi.add(esik)
                    oto = (esik == 15)  # %15'te otomatik yavaşla
                    try:
                        from telegram.bot import sor_onay
                        sor_onay(
                            f"🔋 Batarya %{pil}!\n"
                            f"{'⚠️ Kritik! ' if esik==15 else ''}Sistemi yavaşlatayım mı?",
                            evet_fn=lambda: globals().update({"_hafif_mod": True}),
                            hayir_fn=lambda: globals().update({"_hafif_mod": False}),
                            oto_kadar=oto, oto_sure=600
                        )
                    except Exception: pass
                    break

        # Çok sıcaksa uyar
        if d["sicaklik"] > CPU_KRITIK + 5:
            uyari("ana_bot", f"🌡️ Kritik sıcaklık: {d['sicaklik']}°C")
            _hafif_mod = True
        elif d["sicaklik"] < CPU_KRITIK and _hafif_mod:
            _hafif_mod = False

    except Exception as e: uyari("ana_bot", f"Telefon: {e}")


# ── HİBRİT ÖĞRENME (hızlandırıldı) ──────────────────────
def _ogren():
    try:
        from beyin.feature_flags import acik
        if not acik("ogrenme"): return
        from beyin.ogretici import toplu_ogren
        # Paralel 3 konu
        n = toplu_ogren(3)
        bilgi("ana_bot", f"📚 {n} konu öğrenildi (kuyrukta)")
    except Exception as e: hata("ana_bot", f"Öğrenme: {e}")


# ── KAPALÜ DÖNGÜ (self-improvement) ──────────────────────
def _gorev_dongusu():
    try:
        from beyin.feature_flags import acik
        if not acik("bot_uretim"): return
        from beyin.gorev_uretici import gorev_uret, gorev_tamamla, bekleyen_gorevler
        from beyin.gorev_uretici import gorevi_uygula
        from beyin.geri_bildirim import gelisim_trendi
        bekleyenler = bekleyen_gorevler(1)
        gorev = bekleyenler[0] if bekleyenler else gorev_uret()
        if not gorev: return
        sonuc = gorevi_uygula(gorev)
        if gorev.get("id"): gorev_tamamla(gorev["id"], sonuc.get("ozet",""), sonuc.get("puan",0))
        trend = gelisim_trendi()
        bilgi("ana_bot", f"📈 Trend: {trend}")
        if sonuc.get("basarili") and sonuc.get("puan",0) >= 7:
            try:
                from telegram.bot import mesaj_gonder
                mesaj_gonder(
                    f"✅ <b>Görev Tamamlandı</b>\n"
                    f"📋 {gorev.get('baslik','')[:50]}\n"
                    f"⭐ {sonuc.get('puan',0):.1f}/10 | {trend}"
                )
            except Exception: pass
    except Exception as e: hata("ana_bot", f"Görev: {e}")


# ── İÇ SES (DÜZELTİLDİ — AI artık karışmıyor) ───────────
def _ic_ses():
    """
    İç ses için net prompt — NEXUS güvenlik sistemi sanmasın.
    """
    try:
        from beyin.ai import sor
        from beyin.veritabani import sorgu as db_sorgu
        bilgi_n = db_sorgu("SELECT COUNT(*) as n FROM bilgi_bankasi")[0]["n"]
        son_konu_list = db_sorgu("SELECT konu FROM bilgi_bankasi ORDER BY id DESC LIMIT 3")
        son_konular = ", ".join(b["konu"] for b in son_konu_list) if son_konu_list else "henüz yok"

        prompt = (
            f"Sen NEXUS adlı, Python ile yazılmış, Termux'ta çalışan "
            f"bir otonom öğrenen yapay zeka sistemisin.\n"
            f"Döngü #{_sayac}'deyiz.\n"
            f"Şimdiye kadar {bilgi_n} bilgi öğrendim.\n"
            f"Son öğrendiklerim: {son_konular}\n\n"
            f"Şu an ne hissediyorsun? Ne öğrenmek istiyorsun? "
            f"Kendini geliştirmek için ne yapmayı planlıyorsun?\n"
            f"Kısa ve içten cevap ver."
        )
        cevap = sor(
            prompt,
            sistem=(
                "Sen NEXUS adlı otonom öğrenen bir Python yapay zekasısın. "
                "İnsan gibi düşünce ve his ifade et. "
                "Blockchain veya güvenlik sistemleriyle hiçbir ilgin yok. "
                "Sadece kendin hakkında konuş."
            ),
            sicaklik=0.8, maks_sure=45
        )
        if cevap:
            log_anayz("ana_bot", f"💭 İç ses: {cevap[:80]}...")
            dosya = Path(DOCS_DIR) / "ic_ses.txt"
            dosya.parent.mkdir(parents=True, exist_ok=True)
            with dosya.open("a", encoding="utf-8") as f:
                f.write(f"\n[{datetime.now().strftime('%H:%M')} Döngü#{_sayac}]\n{cevap}\n")
    except Exception as e: hata("ana_bot", f"İç ses: {e}")


# ── BOT ÜRETİMİ ──────────────────────────────────────────
def _bot_kontrol():
    try:
        from beyin.feature_flags import acik
        if not acik("bot_uretim"): return
        from zeka.anayz import anayz_al
        from beyin.bot_yonetici import bot_olustur, aktif_botlar
        mevcut = [b["uzmanlik"] for b in aktif_botlar()]
        gerekli = ["sistem_otomasyonu", "ag_analizi", "dil_isleme", "goruntu_analizi"]
        eksik = [u for u in gerekli if u not in mevcut]
        if not eksik: return
        az = anayz_al()
        ok, _ = az.oyla(f"{eksik[0]} botu üretilsin mi?", f"Mevcut: {mevcut}")
        if ok:
            threading.Thread(
                target=bot_olustur,
                args=(eksik[0], f"{eksik[0]} uzmanı otonom bot"),
                daemon=True, name=f"uret-{eksik[0]}"
            ).start()
    except Exception as e: hata("ana_bot", f"Bot kontrol: {e}")


# ── RAPOR ────────────────────────────────────────────────
def _rapor():
    try:
        from telegram.bot import mesaj_gonder
        from beyin.geri_bildirim import ortalama_puan, gelisim_trendi
        bilgi_n = sorgu("SELECT COUNT(*) as n FROM bilgi_bankasi")[0]["n"]
        bot_n   = sorgu("SELECT COUNT(*) as n FROM botlar WHERE aktif=1")[0]["n"]
        gorev_n = sorgu("SELECT COUNT(*) as n FROM uretilen_gorevler WHERE durum='tamamlandi'")[0]["n"]
        uptime  = str(datetime.now() - _baslangic).split(".")[0]
        mesaj_gonder(
            f"📊 <b>NEXUS v6 Rapor</b>\n"
            f"{'─'*20}\n"
            f"⏱️ Uptime: {uptime}\n"
            f"🔄 Döngü: #{_sayac}\n"
            f"📚 Bilgi: {bilgi_n} kayıt\n"
            f"🤖 Dinamik Bot: {bot_n}\n"
            f"✅ Görev: {gorev_n}\n"
            f"⭐ Ort: {ortalama_puan()}/10\n"
            f"📈 {gelisim_trendi()}"
        )
    except Exception as e: hata("ana_bot", f"Rapor: {e}")


def _yedek():
    try:
        from beyin.feature_flags import acik
        if not acik("yedekleme"): return
        from sistem.yedekleme import yedek_al
        threading.Thread(target=yedek_al, daemon=True, name="yedek").start()
    except Exception as e: hata("ana_bot", f"Yedek: {e}")


# ── ANA DÖNGÜ (HIZLANDIRILDI) ───────────────────────────
def ana_dongu():
    global _sayac
    bilgi("ana_bot", "♾️ Kapalı döngü — v6 aktif!")
    son = {k: datetime.now() for k in
           ["ogren","gorev","bot","ic","rapor","yedek","telefon"]}

    def gecen(k, sn):
        return (datetime.now() - son[k]).total_seconds() > sn

    while True:
        try:
            with _sayac_lock: _sayac += 1

            # Telefon: 5dk
            if gecen("telefon", 300):
                threading.Thread(target=_telefon_kontrol, daemon=True).start()
                son["telefon"] = datetime.now()

            if _hafif_mod:
                uyari("ana_bot", "⚠️ Hafif mod — 60sn bekleniyor")
                time.sleep(60); continue

            # Öğrenme: 60sn (hızlandırıldı, eski: 120sn)
            if gecen("ogren", 60):
                threading.Thread(target=_ogren, daemon=True, name="ogren").start()
                son["ogren"] = datetime.now()

            # Görev: 180sn (eski: 240sn)
            if gecen("gorev", 180):
                threading.Thread(target=_gorev_dongusu, daemon=True, name="gorev").start()
                son["gorev"] = datetime.now()

            # Bot üretimi: 480sn
            if gecen("bot", 480):
                threading.Thread(target=_bot_kontrol, daemon=True, name="bot_k").start()
                son["bot"] = datetime.now()

            # İç ses: 15dk (daha sık, düzeltilmiş prompt)
            if gecen("ic", 900):
                threading.Thread(target=_ic_ses, daemon=True, name="ic_ses").start()
                son["ic"] = datetime.now()

            # Rapor: 6 saat
            if gecen("rapor", 21600):
                threading.Thread(target=_rapor, daemon=True).start()
                son["rapor"] = datetime.now()

            # Yedek: 24 saat
            if gecen("yedek", 86400):
                threading.Thread(target=_yedek, daemon=True).start()
                son["yedek"] = datetime.now()

            bilgi("ana_bot", f"💫 Döngü #{_sayac}")
            time.sleep(DONGU_SURESI)  # 8sn (eski: 15sn)

        except KeyboardInterrupt:
            bilgi("ana_bot", "⏹️ Ctrl+C"); break
        except Exception as e:
            hata("ana_bot", f"Döngü: {e}"); time.sleep(5)

def main():
    sistem_hazirla()
    ana_dongu()

if __name__ == "__main__":
    main()
