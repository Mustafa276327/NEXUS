"""NEXUS v6 - Logger — saat formatı düzeltildi (54+00:00 sorunu giderildi)"""
from __future__ import annotations
import json, logging, logging.handlers, queue, threading, time, uuid
from datetime import datetime, timezone
from pathlib import Path

def _kayit_dir() -> Path:
    from beyin.config import KAYIT_DIR
    KAYIT_DIR.mkdir(parents=True, exist_ok=True)
    return KAYIT_DIR

_flog = logging.getLogger("nexus")
_flog.setLevel(logging.DEBUG)
_handler_ok = False

def _handler_ekle():
    global _handler_ok
    if _handler_ok: return
    try:
        h = logging.handlers.RotatingFileHandler(
            str(_kayit_dir() / "nexus.log"),
            maxBytes=5*1024*1024, backupCount=5, encoding="utf-8"
        )
        h.setFormatter(logging.Formatter("%(message)s"))
        _flog.addHandler(h)
        _handler_ok = True
    except Exception:
        pass

_buffer: list = []
_buf_lock = threading.Lock()
MAX_BUF = 500
_dusurülen = 0
_dbq: queue.Queue = queue.Queue(maxsize=3000)
_db_ok = False
_db_lock = threading.Lock()

def _db_worker():
    while True:
        try:
            item = _dbq.get(timeout=5)
            if item is None: break
            sev, mod, msg, ts, cid = item
            try:
                from beyin.veritabani import log_yaz_direkt
                log_yaz_direkt(sev, mod, msg, ts, cid)
            except Exception:
                try:
                    with (_kayit_dir() / "fallback.log").open("a", encoding="utf-8") as f:
                        f.write(f"{ts}|{sev}|{mod}|{msg}\n")
                except Exception:
                    pass
            finally:
                _dbq.task_done()
        except queue.Empty:
            continue
        except Exception:
            continue

def _db_baslat():
    global _db_ok
    with _db_lock:
        if not _db_ok:
            threading.Thread(target=_db_worker, daemon=True, name="nexus-log-db").start()
            _db_ok = True

_R = {
    "BILGI": "\033[94m", "BASARI": "\033[92m", "UYARI": "\033[93m",
    "HATA":  "\033[91m", "KARAR":  "\033[95m", "ANAYZ": "\033[96m",
    "S": "\033[0m", "K": "\033[1m", "KO": "\033[2m",
}

def log(seviye: str, modul: str, mesaj: str, cid: str = ""):
    global _dusurülen
    _db_baslat()
    _handler_ekle()

    # ── Saat formatı düzeltmesi ────────────────────────────
    # Sorun: datetime(timezone.utc) → "07:05:01+00:00" → parse yanlış
    # Çözüm: yerel saat kullan, sadece HH:MM:SS
    simdi     = datetime.now()
    zaman_kisa = simdi.strftime("%H:%M:%S")
    zaman_iso  = simdi.isoformat(timespec="seconds")

    renk = _R.get(seviye, "")
    cid_str = f" [{cid}]" if cid else ""
    print(
        f"{_R['K']}{renk}[{seviye:<6}]{_R['S']} "
        f"{_R['KO']}{zaman_kisa}{_R['S']} "
        f"{renk}[{modul}]{_R['S']}{cid_str} {mesaj}"
    )

    kayit = {
        "ts": zaman_iso, "level": seviye,
        "module": modul, "msg": mesaj, "trace_id": cid,
    }
    try:
        _flog.info(json.dumps(kayit, ensure_ascii=False))
    except Exception:
        pass

    kisa = {"zaman": zaman_kisa, "seviye": seviye, "modul": modul, "mesaj": mesaj, "cid": cid}
    with _buf_lock:
        if len(_buffer) >= MAX_BUF:
            _buffer.pop(0)
            _dusurülen += 1
        _buffer.append(kisa)

    try:
        _dbq.put_nowait((seviye, modul, mesaj[:500], zaman_iso, cid))
    except queue.Full:
        _dusurülen += 1

def son_loglar(n: int = 100) -> list:
    with _buf_lock:
        return list(_buffer[-n:])

def dusurülen_sayisi() -> int:
    return _dusurülen

def bilgi(m, msg, cid=""):  log("BILGI",  m, msg, cid)
def basari(m, msg, cid=""): log("BASARI", m, msg, cid)
def uyari(m, msg, cid=""):  log("UYARI",  m, msg, cid)
def hata(m, msg, cid=""):   log("HATA",   m, msg, cid)
def karar(m, msg, cid=""):  log("KARAR",  m, msg, cid)
def anayz(m, msg, cid=""):  log("ANAYZ",  m, msg, cid)
