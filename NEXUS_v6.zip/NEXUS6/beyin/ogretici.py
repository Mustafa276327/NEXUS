"""
NEXUS v6 - Gelişmiş Öğretici
- Kategori sistemi (Yazilim, Kultur, Bilim, Teknoloji, Ekonomi)
- Zincir öğrenme: AI bir önceki konudan ilişkili yeni konu önerir
- Kaynak bulunamazsa → AI'ya sor (düzeltildi)
- VeriDuzenleyici kuyruğuna yazar (race condition yok)
- Paralel 3 konu aynı anda
- 60-90 dakikada bir kategori değiştir
"""
from __future__ import annotations
import random, sqlite3, time, threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from urllib.parse import quote
import requests
from beyin.config import DEPO_DIR, KATEGORILER
from beyin.logger import bilgi, hata, uyari, basari

_H = {"User-Agent": "NEXUS-AI/6.0 (educational)"}

# Aktif kategori ve zincir durumu
_aktif_kategori = "Yazilim"
_son_kategori_degisim = time.monotonic()
_kategori_lock = threading.Lock()
KATEGORI_DEGISIM_ARALIĞI = random.randint(7200, 10800)  # 2-3 saat

def _kategori_guncelle():
    """2-3 saatte bir rastgele kategori değiştir"""
    global _aktif_kategori, _son_kategori_degisim, KATEGORI_DEGISIM_ARALIĞI
    with _kategori_lock:
        if time.monotonic() - _son_kategori_degisim > KATEGORI_DEGISIM_ARALIĞI:
            agirliklar = [(k, v["agirlik"]) for k, v in KATEGORILER.items()]
            isimler  = [a[0] for a in agirliklar]
            agirlik  = [a[1] for a in agirliklar]
            yeni = random.choices(isimler, weights=agirlik, k=1)[0]
            if yeni != _aktif_kategori:
                bilgi("ogretici", f"🔄 Kategori değişti: {_aktif_kategori} → {yeni}")
                _aktif_kategori = yeni
            _son_kategori_degisim = time.monotonic()
            KATEGORI_DEGISIM_ARALIĞI = random.randint(7200, 10800)
    return _aktif_kategori

def _sonraki_konu(kategori: str) -> str:
    """
    Zincir öğrenme:
    1. DB'deki son konuya bakılır
    2. AI o konuyla ilişkili yeni konu önerir
    3. Yoksa başlangıç listesinden rastgele seç
    """
    try:
        con = sqlite3.connect(str(DEPO_DIR / "nexus.db"), timeout=5)
        son = con.execute(
            "SELECT konu FROM bilgi_bankasi WHERE kategori=? ORDER BY id DESC LIMIT 1",
            (kategori,)
        ).fetchone()
        con.close()

        if son:
            onceki = son[0]
            from beyin.ai import sor
            oneri = sor(
                f"Şimdiye kadar '{onceki}' öğrendim.\n"
                f"Kategori: {kategori}\n"
                f"Bu konuyla ilişkili, aynı kategoride, "
                f"ama farklı bir konu öner. Sadece konu adını yaz (2-5 kelime).",
                sistem="Sen bir öğrenme asistanısın. Sadece konu adı ver.",
                sicaklik=0.7, maks_sure=30,
            )
            if oneri and len(oneri.strip()) < 60:
                konu = oneri.strip().split("\n")[0]
                bilgi("ogretici", f"🔗 Zincir: {onceki} → {konu}")
                return konu
    except Exception:
        pass

    # Başlangıç listesinden seç
    return random.choice(KATEGORILER[kategori]["baslangic"])

def wikipedia_oku(konu: str, dil: str = "tr") -> str:
    try:
        r = requests.get(
            f"https://{dil}.wikipedia.org/api/rest_v1/page/summary/{quote(konu)}",
            headers=_H, timeout=12
        )
        if r.status_code == 200:
            ozet = r.json().get("extract", "")
            if len(ozet) > 80:
                return ozet[:2000]
        if dil == "tr":
            return wikipedia_oku(konu, "en")
    except Exception as e:
        uyari("ogretici", f"Wikipedia ({konu}): {e}")
    return ""

def stackoverflow_oku(konu: str) -> str:
    try:
        r = requests.get(
            f"https://api.stackexchange.com/2.3/search/advanced"
            f"?order=desc&sort=votes&q={quote(konu)}&site=stackoverflow&pagesize=2",
            headers=_H, timeout=10
        )
        if r.status_code == 200:
            items = r.json().get("items", [])
            if items:
                return " | ".join(i.get("title", "") for i in items[:2])
    except Exception:
        pass
    return ""

def github_ara(konu: str) -> str:
    try:
        r = requests.get(
            f"https://api.github.com/search/repositories"
            f"?q={quote(konu)}+language:python&sort=stars&per_page=2",
            headers=_H, timeout=10
        )
        if r.status_code == 200:
            items = r.json().get("items", [])
            if items:
                return " | ".join(f"{i['full_name']}(★{i['stargazers_count']})" for i in items[:2])
    except Exception:
        pass
    return ""

def ai_den_ogren(konu: str, kategori: str) -> str:
    """Kaynak bulunamazsa AI'dan direkt öğren (düzeltildi)"""
    from beyin.ai import sor
    bilgi("ogretici", f"🤖 AI'dan öğreniliyor: {konu}")
    cevap = sor(
        f"Konu: {konu}\nKategori: {kategori}\n\n"
        "Bu konu hakkında:\n"
        "1. Kısa tanım (1-2 cümle)\n"
        "2. 3 önemli nokta\n"
        "3. Pratik örnek\n"
        "4. Neden önemli?\n\n"
        "Türkçe, net, 200 kelime max.",
        maks_sure=60,
    )
    return cevap or ""

def _veri_kuyruğuna_gonder(bot_isim: str, kategori: str, konu: str,
                            icerik: str, kaynak: str):
    """VeriDuzenleyici kuyruğuna yaz (race condition yok)"""
    try:
        con = sqlite3.connect(str(DEPO_DIR / "nexus.db"), timeout=30)
        con.execute("PRAGMA journal_mode=WAL")
        con.execute(
            "INSERT INTO veri_kuyruğu(bot_isim,kategori,konu,icerik,kaynak,tarih) "
            "VALUES(?,?,?,?,?,?)",
            (bot_isim, kategori, konu, icerik[:2000], kaynak, datetime.now().isoformat())
        )
        con.commit()
        con.close()
    except Exception as e:
        hata("ogretici", f"Kuyruk yazma: {e}")

def hibrit_ogren(konu: str, kategori: str = "", bot_isim: str = "Ogretici") -> bool:
    """
    Öğrenme akışı:
    1. Wikipedia (TR/EN) + StackOverflow + GitHub paralel
    2. Kaynak yoksa → AI'ya doğrudan sor
    3. AI ile özet çıkar
    4. VeriDuzenleyici kuyruğuna gönder
    """
    if not kategori:
        kategori = _aktif_kategori

    bilgi("ogretici", f"🌐 [{kategori}] Öğreniliyor: {konu}")

    # Paralel kaynak toplama
    ham_parcalar = {}
    with ThreadPoolExecutor(max_workers=3) as ex:
        isler = {
            ex.submit(wikipedia_oku, konu): "wiki",
            ex.submit(stackoverflow_oku, konu): "so",
            ex.submit(github_ara, konu): "github",
        }
        for g in as_completed(isler, timeout=20):
            k = isler[g]
            try:
                v = g.result()
                if v: ham_parcalar[k] = v
            except Exception:
                pass

    ham = "\n\n".join(
        f"[{k.upper()}]\n{v[:600]}" for k, v in ham_parcalar.items()
    )

    # Kaynak bulunamazsa AI'ya sor (DÜZELTİLDİ)
    if not ham:
        uyari("ogretici", f"Web kaynağı yok: {konu} — AI'ya sorulacak")
        ham = ai_den_ogren(konu, kategori)
        if not ham:
            hata("ogretici", f"AI de cevap vermedi: {konu}")
            return False
        kaynak = "AI-Direct"
    else:
        kaynak = "+".join(ham_parcalar.keys()) + "+AI"

    # AI ile anlamlı özet
    from beyin.ai import sor
    ozet = sor(
        f"Kategori: {kategori}\nKonu: {konu}\n\nKaynak:\n{ham[:1500]}\n\n"
        "Öğrenme özeti:\n"
        "1. Ana tanım (1 cümle)\n"
        "2. 4 önemli nokta\n"
        "3. Pratik örnek\n"
        "4. {kategori} kategorisinde neden önemli?\n\n"
        "Türkçe, net, uygulanabilir.",
        maks_sure=120,
    )
    icerik = ozet if ozet else ham[:600]

    # VeriDuzenleyici kuyruğuna gönder
    _veri_kuyruğuna_gonder(bot_isim, kategori, konu, icerik, kaynak)
    basari("ogretici", f"✅ Kuyruğa eklendi: [{kategori}] {konu}")

    # Öğrenme zincirini kaydet
    try:
        con = sqlite3.connect(str(DEPO_DIR / "nexus.db"), timeout=10)
        con.execute("PRAGMA journal_mode=WAL")
        son = con.execute(
            "SELECT konu FROM bilgi_bankasi WHERE kategori=? ORDER BY id DESC LIMIT 1",
            (kategori,)
        ).fetchone()
        if son:
            con.execute(
                "INSERT OR IGNORE INTO ogrenme_zinciri(kategori,onceki_konu,sonraki_konu) "
                "VALUES(?,?,?)",
                (kategori, son[0], konu)
            )
        con.commit()
        con.close()
    except Exception:
        pass

    return True

def toplu_ogren(sayi: int = 3) -> int:
    """Aktif kategoriden paralel öğrenme"""
    kategori = _kategori_guncelle()
    konular = [_sonraki_konu(kategori) for _ in range(sayi)]
    # Tekrar önle
    konular = list(set(konular))[:sayi]
    basarili = 0
    with ThreadPoolExecutor(max_workers=3) as ex:
        isler = {ex.submit(hibrit_ogren, k, kategori): k for k in konular}
        for g in as_completed(isler, timeout=300):
            if g.result():
                basarili += 1
    bilgi("ogretici", f"📚 Toplu: {basarili}/{len(konular)} [{kategori}]")
    return basarili

def rastgele_ogren() -> bool:
    kategori = _kategori_guncelle()
    konu = _sonraki_konu(kategori)
    return hibrit_ogren(konu, kategori)
