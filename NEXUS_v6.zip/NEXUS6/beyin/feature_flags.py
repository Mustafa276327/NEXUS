"""NEXUS v6 - Feature Flags (fail-closed)"""
from __future__ import annotations
import json, threading, time
from pathlib import Path
from beyin.config import FEAT_PATH
from beyin.logger import bilgi, uyari

_flags: dict = {}
_lock = threading.RLock()
_son = 0.0
_VARSAYILAN = {
    "ogrenme": True, "bot_uretim": True, "telegram": True,
    "yedekleme": True, "health_check": True, "veri_duzenleyici": True,
}

def yukle():
    global _son
    try:
        p = Path(FEAT_PATH)
        if not p.exists():
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(json.dumps(_VARSAYILAN, indent=2, ensure_ascii=False))
        yeni = json.loads(p.read_text(encoding="utf-8"))
        with _lock:
            _flags.clear(); _flags.update(yeni)
        _son = time.time()
    except Exception as e:
        uyari("flags", f"Yüklenemedi: {e}")
        with _lock:
            if not _flags: _flags.update(_VARSAYILAN)

def acik(f: str) -> bool:
    if time.time() - _son > 30: yukle()
    with _lock:
        if f not in _flags:
            uyari("flags", f"Bilinmeyen flag (kapalı): {f}")
            return False
        return bool(_flags[f])

def toggle(f: str, d: bool):
    with _lock:
        _flags[f] = d
        try:
            Path(FEAT_PATH).write_text(
                json.dumps(_flags, indent=2, ensure_ascii=False), encoding="utf-8"
            )
            bilgi("flags", f"{f}={'açık' if d else 'kapalı'}")
        except Exception as e:
            uyari("flags", f"Kaydedilemedi: {e}")

def tumu() -> dict:
    with _lock: return dict(_flags)

yukle()
