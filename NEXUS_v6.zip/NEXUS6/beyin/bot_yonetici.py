"""NEXUS v6 - Bot Yöneticisi + Hazır Botlar"""
from __future__ import annotations
import os, re, subprocess, sys, threading, atexit
from datetime import datetime
from pathlib import Path
from typing import Optional, List
from beyin.config import BOTLAR_DIR, BOT_AKTIF, BOT_FAIL, RUTBELER
from beyin.logger import bilgi, hata, uyari, basari
from beyin.veritabani import baglanti, sorgu

_lock = threading.Lock()
_prosesler: dict[str, subprocess.Popen] = {}
_izleme_aktif = threading.Event()

@atexit.register
def _temizle():
    _izleme_aktif.clear()
    with _lock:
        for p in _prosesler.values():
            if p.poll() is None:
                p.terminate()
                try: p.wait(timeout=3)
                except subprocess.TimeoutExpired: p.kill()

def _isim_dogrula(i: str) -> bool:
    return bool(re.fullmatch(r"[a-zA-Z][a-zA-Z0-9_]{1,25}", i))

def _bot_izle(isim: str, yol: str):
    sayac = 0
    while _izleme_aktif.is_set():
        with _lock:
            p = _prosesler.get(isim)
        if p and p.poll() is not None:
            p.wait(); sayac += 1
            uyari("bot_yonetici", f"💀 {isim} çöktü (#{sayac})")
            import time; time.sleep(min(5*sayac, 30))
            _baslat_ic(isim, yol)
        import time; time.sleep(10)

def _baslat_ic(isim: str, yol: str):
    if not Path(yol).exists(): return
    try:
        p = subprocess.Popen(
            [sys.executable, yol], stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL, cwd=str(BOT_AKTIF)
        )
        with _lock: _prosesler[isim] = p
        bilgi("bot_yonetici", f"▶️ {isim} (PID:{p.pid})")
    except Exception as e:
        hata("bot_yonetici", f"Başlatma ({isim}): {e}")

def izlemeyi_baslat():
    _izleme_aktif.set()
    try:
        botlar = sorgu("SELECT isim,kod_yolu FROM botlar WHERE aktif=1 AND kod_yolu IS NOT NULL")
        for b in botlar:
            if b["kod_yolu"] and Path(b["kod_yolu"]).exists():
                threading.Thread(target=_bot_izle, args=(b["isim"],b["kod_yolu"]),
                                 daemon=True, name=f"izle-{b['isim']}").start()
        bilgi("bot_yonetici", f"🔍 {len(botlar)} bot izleniyor")
    except Exception as e: hata("bot_yonetici", f"İzleme: {e}")

def aktif_botlar() -> List[dict]:
    return sorgu("SELECT isim,rutbe,uzmanlik,profesyonellik_puani FROM botlar WHERE aktif=1 ORDER BY profesyonellik_puani DESC")

def bot_olustur(uzmanlik: str, gorev: str, kategori: str = "genel") -> Optional[str]:
    from beyin.ai import kod_yaz, isim_sec
    from sistem.guvenlik import kod_tara
    bilgi("bot_yonetici", f"🤖 {uzmanlik}")
    isim = isim_sec(uzmanlik) or f"Bot{int(datetime.now().timestamp())%10000}"
    if not _isim_dogrula(isim): isim = f"Bot{int(datetime.now().timestamp())%10000}"
    kod = kod_yaz(
        f"Uzmanlik: {uzmanlik}\nGörev: {gorev[:300]}\n"
        "Sonsuz döngü, 30sn aralık, hata yakala, devam et. Sadece stdlib."
    )
    if not kod: return None
    temiz, bulgular = kod_tara(kod)
    if not temiz: _fail_kaydet(isim, kod, str(bulgular)); return None
    BOT_AKTIF.mkdir(parents=True, exist_ok=True)
    yol = str(BOT_AKTIF / f"{isim}.py")
    try:
        with open(yol, "w", encoding="utf-8") as f: f.write(kod)
    except OSError as e: hata("bot_yonetici", f"Dosya: {e}"); return None
    con = baglanti()
    try:
        con.execute(
            "INSERT OR IGNORE INTO botlar(isim,rutbe,uzmanlik,olusturma_tarihi,kod_yolu,aktif,kategori) "
            "VALUES(?,?,?,?,?,1,?)",
            (isim, "yeni", uzmanlik, datetime.now().isoformat(), yol, kategori)
        )
        con.commit(); basari("bot_yonetici", f"✅ {isim} [{uzmanlik}]")
    except Exception as e:
        con.rollback(); hata("bot_yonetici", f"DB: {e}"); return None
    finally: con.close()
    if _izleme_aktif.is_set():
        threading.Thread(target=_bot_izle, args=(isim,yol), daemon=True).start()
    return isim

def _fail_kaydet(isim: str, kod: str, sebep: str):
    BOT_FAIL.mkdir(parents=True, exist_ok=True)
    try:
        with open(str(BOT_FAIL/f"{isim}_fail.py"), "w", encoding="utf-8") as f:
            f.write(f"# {sebep}\n\n{kod}")
    except OSError: pass

def rutbe_guncelle(isim: str):
    con = baglanti()
    try:
        r = con.execute("SELECT profesyonellik_puani,rutbe FROM botlar WHERE isim=?", (isim,)).fetchone()
        if not r: return
        yeni = next((rd for rd, bi in reversed(list(RUTBELER.items()))
                     if r["profesyonellik_puani"] >= bi["puan"]), r["rutbe"])
        if yeni != r["rutbe"]:
            con.execute("UPDATE botlar SET rutbe=? WHERE isim=?", (yeni, isim))
            con.commit(); basari("bot_yonetici", f"🎖️ {isim}: {r['rutbe']}→{yeni}")
    except Exception: pass
    finally: con.close()
