"""NEXUS v6 - Veritabanı"""
from __future__ import annotations
import sqlite3, threading
from datetime import datetime
from pathlib import Path
from beyin.config import DB_PATH, DEPO_DIR

_lock = threading.Lock()

def baglanti() -> sqlite3.Connection:
    DEPO_DIR.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(DB_PATH), check_same_thread=False, timeout=30)
    con.execute("PRAGMA foreign_keys=ON")
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA synchronous=NORMAL")
    con.row_factory = sqlite3.Row
    return con

def tablolari_olustur():
    con = baglanti()
    try:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS sistem_meta(anahtar TEXT PRIMARY KEY, deger TEXT);
        CREATE TABLE IF NOT EXISTS botlar(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            isim TEXT UNIQUE NOT NULL, rutbe TEXT DEFAULT 'yeni',
            profesyonellik_puani REAL DEFAULT 0, uzmanlik TEXT,
            olusturma_tarihi TEXT NOT NULL, duygusal_durum TEXT DEFAULT 'merakli',
            gorev_sayisi INTEGER DEFAULT 0, basari_sayisi INTEGER DEFAULT 0,
            hata_sayisi INTEGER DEFAULT 0, kod_yolu TEXT,
            aktif INTEGER DEFAULT 1, son_aktif TEXT, kategori TEXT
        );
        CREATE TABLE IF NOT EXISTS bilgi_bankasi(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            kategori TEXT, alt_kategori TEXT, konu TEXT NOT NULL,
            icerik TEXT NOT NULL, kaynak TEXT,
            tarih TEXT NOT NULL, puan REAL DEFAULT 0, bot_isim TEXT
        );
        CREATE TABLE IF NOT EXISTS ogrenme_zinciri(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            kategori TEXT, onceki_konu TEXT, sonraki_konu TEXT,
            gecis_sayisi INTEGER DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS gorevler(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            baslik TEXT NOT NULL, aciklama TEXT, oncelik INTEGER DEFAULT 5,
            durum TEXT DEFAULT 'bekliyor', atanan_bot TEXT,
            olusturma TEXT NOT NULL, tamamlanma TEXT, sonuc TEXT, cid TEXT
        );
        CREATE TABLE IF NOT EXISTS kararlar(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            karar TEXT NOT NULL, gerekce TEXT, oylama_sonucu TEXT,
            tarih TEXT NOT NULL, uygulandi INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS olaylar(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            seviye TEXT, modul TEXT, mesaj TEXT, tarih TEXT NOT NULL, cid TEXT
        );
        CREATE TABLE IF NOT EXISTS uretilen_gorevler(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            kategori TEXT, baslik TEXT, aciklama TEXT, zorluk INTEGER,
            durum TEXT DEFAULT 'bekliyor', sonuc TEXT, puan REAL DEFAULT 0,
            olusturma TEXT, tamamlanma TEXT
        );
        CREATE TABLE IF NOT EXISTS geri_bildirimler(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            gorev TEXT, puan REAL, yorum TEXT, tarih TEXT
        );
        CREATE TABLE IF NOT EXISTS beceri_kutuphanesi(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            isim TEXT UNIQUE NOT NULL, kod TEXT NOT NULL,
            puan REAL DEFAULT 0, kullanim_sayisi INTEGER DEFAULT 0,
            cikti_ornegi TEXT, kategori TEXT, tarih TEXT
        );
        CREATE TABLE IF NOT EXISTS anayasa(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            madde INTEGER UNIQUE, icerik TEXT, olusturma TEXT, onaylayan TEXT
        );
        CREATE TABLE IF NOT EXISTS veri_kuyruğu(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            bot_isim TEXT, kategori TEXT, konu TEXT, icerik TEXT,
            kaynak TEXT, tarih TEXT, islendi INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS tg_offset(id INTEGER PRIMARY KEY, offset INTEGER DEFAULT 0);
        CREATE INDEX IF NOT EXISTS idx_olaylar_tarih ON olaylar(tarih);
        CREATE INDEX IF NOT EXISTS idx_bilgi_kategori ON bilgi_bankasi(kategori);
        CREATE INDEX IF NOT EXISTS idx_bilgi_tarih ON bilgi_bankasi(tarih);
        CREATE INDEX IF NOT EXISTS idx_veri_islendi ON veri_kuyruğu(islendi);
        """)
        con.commit()
        print("✅ Veritabanı hazır (v6)")
    except Exception as e:
        con.rollback()
        raise RuntimeError(f"DB hatası: {e}") from e
    finally:
        con.close()

def log_yaz_direkt(sev, mod, msg, ts, cid=""):
    con = baglanti()
    try:
        con.execute("INSERT INTO olaylar(seviye,modul,mesaj,tarih,cid) VALUES(?,?,?,?,?)",
                    (sev, mod, msg[:1000], ts, cid))
        con.commit()
    except Exception:
        con.rollback()
    finally:
        con.close()

def sorgu(sql: str, params: tuple = ()) -> list:
    con = baglanti()
    try:
        return [dict(r) for r in con.execute(sql, params).fetchall()]
    finally:
        con.close()

def yazdir(sql: str, params: tuple = ()):
    con = baglanti()
    try:
        con.execute(sql, params)
        con.commit()
    except Exception as e:
        con.rollback()
        raise RuntimeError(f"DB yazma: {e}") from e
    finally:
        con.close()

def tg_offset_al() -> int:
    con = baglanti()
    try:
        r = con.execute("SELECT offset FROM tg_offset WHERE id=1").fetchone()
        return r["offset"] if r else 0
    finally:
        con.close()

def tg_offset_kaydet(offset: int):
    con = baglanti()
    try:
        con.execute("INSERT OR REPLACE INTO tg_offset(id,offset) VALUES(1,?)", (offset,))
        con.commit()
    except Exception:
        con.rollback()
    finally:
        con.close()

def puan_guncelle(isim: str, puan: float, basarili: bool):
    with _lock:
        con = baglanti()
        try:
            if basarili:
                con.execute(
                    "UPDATE botlar SET profesyonellik_puani=profesyonellik_puani+?,"
                    "basari_sayisi=basari_sayisi+1,gorev_sayisi=gorev_sayisi+1,son_aktif=? WHERE isim=?",
                    (puan, datetime.now().isoformat(), isim))
            else:
                con.execute(
                    "UPDATE botlar SET profesyonellik_puani=MAX(0,profesyonellik_puani-?),"
                    "hata_sayisi=hata_sayisi+1,gorev_sayisi=gorev_sayisi+1 WHERE isim=?",
                    (puan/2, isim))
            con.commit()
        except Exception:
            con.rollback()
        finally:
            con.close()
