"""NEXUS v6 - Görev Üretici + Uygulama Motoru + Health Check"""
# ── GÖREV ÜRETİCİ ────────────────────────────────────────
import random, sqlite3, subprocess, tempfile, shutil, os, sys, time, threading
from datetime import datetime
from pathlib import Path
from beyin.config import DEPO_DIR, CPU_KRITIK, BATARYA_KRITIK
from beyin.logger import bilgi, hata, uyari, basari

GOREV_SABLONLARI = [
    ("kod_yazma",    "Python ile {konu} konusunda çalışan bir fonksiyon yaz ve test et", 2),
    ("arastirma",    "{konu} konusunu araştır ve özetle", 1),
    ("analiz",       "Bilgi bankasındaki {konu} verilerini analiz et ve özet çıkar", 2),
    ("test",         "{konu} fonksiyonu için test senaryoları yaz", 3),
    ("bot_uretimi",  "{konu} konusunda uzmanlaşmış bot planı hazırla", 3),
]

def _db():
    con = sqlite3.connect(str(DEPO_DIR/"nexus.db"), timeout=30)
    con.execute("PRAGMA journal_mode=WAL")
    con.row_factory = sqlite3.Row
    return con

def gorev_uret(ai_destekli: bool = True) -> dict:
    sablon = random.choice(GOREV_SABLONLARI)
    from beyin.ogretici import _aktif_kategori, _sonraki_konu
    kategori = _aktif_kategori
    konu = _sonraki_konu(kategori)
    kat, sablon_metin, zorluk = sablon
    aciklama = sablon_metin.format(konu=konu)
    if ai_destekli:
        try:
            from beyin.ai import sor
            ac = sor(f"Görevi somutlaştır: {aciklama}\nAdımlar, beklenti, başarı kriteri. 3 cümle max.", maks_sure=30)
            if ac: aciklama = ac
        except Exception: pass
    gorev = {"kategori": kat, "baslik": f"{kat.upper()}: {konu}", "aciklama": aciklama, "zorluk": zorluk}
    con = _db()
    try:
        cur = con.execute(
            "INSERT INTO uretilen_gorevler(kategori,baslik,aciklama,zorluk,olusturma) VALUES(?,?,?,?,?)",
            (kat, gorev["baslik"], aciklama, zorluk, datetime.now().isoformat())
        )
        gorev["id"] = cur.lastrowid; con.commit()
        bilgi("gorev_uretici", f"📋 {gorev['baslik']}")
    except Exception as e: hata("gorev_uretici", f"DB: {e}")
    finally: con.close()
    return gorev

def bekleyen_gorevler(limit: int = 3) -> list:
    con = _db()
    try:
        return [dict(r) for r in con.execute(
            "SELECT * FROM uretilen_gorevler WHERE durum='bekliyor' ORDER BY zorluk ASC LIMIT ?", (limit,)
        ).fetchall()]
    finally: con.close()

def gorev_tamamla(gid: int, sonuc: str, puan: float):
    con = _db()
    try:
        con.execute("UPDATE uretilen_gorevler SET durum='tamamlandi',sonuc=?,puan=?,tamamlanma=? WHERE id=?",
                    (sonuc[:1000], puan, datetime.now().isoformat(), gid))
        con.commit()
    except Exception as e: hata("gorev_uretici", f"Tamamlama: {e}")
    finally: con.close()

def istatistik() -> dict:
    con = _db()
    try:
        return {
            "toplam":    con.execute("SELECT COUNT(*) FROM uretilen_gorevler").fetchone()[0],
            "tamamlanan":con.execute("SELECT COUNT(*) FROM uretilen_gorevler WHERE durum='tamamlandi'").fetchone()[0],
            "ort_puan":  round(con.execute("SELECT AVG(puan) FROM uretilen_gorevler WHERE durum='tamamlandi'").fetchone()[0] or 0, 2),
        }
    finally: con.close()

# ── UYGULAMA MOTORU ───────────────────────────────────────
def _sandbox(kod: str, timeout: int = 20) -> dict:
    tmp = tempfile.mkdtemp(prefix="nexus_sb_")
    try:
        dosya = os.path.join(tmp, "g.py")
        with open(dosya, "w", encoding="utf-8") as f: f.write(kod)
        t0 = time.monotonic()
        proc = subprocess.Popen(
            [sys.executable, dosya], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            cwd=tmp, env={"PATH": os.environ.get("PATH",""), "HOME": tmp},
            start_new_session=True,
        )
        try:
            out, err = proc.communicate(timeout=timeout)
            return {"basarili": proc.returncode==0,
                    "cikti": out.decode("utf-8","ignore")[:400],
                    "hata":  err.decode("utf-8","ignore")[:200],
                    "sure":  round(time.monotonic()-t0, 2)}
        except subprocess.TimeoutExpired:
            try:
                import signal; os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
            except Exception: proc.kill()
            proc.communicate()
            return {"basarili": False, "cikti": "", "hata": f"Timeout({timeout}sn)", "sure": timeout}
    except Exception as e:
        return {"basarili": False, "cikti": "", "hata": str(e), "sure": 0}
    finally: shutil.rmtree(tmp, ignore_errors=True)

def gorevi_uygula(gorev: dict) -> dict:
    from beyin.ai import kod_yaz
    from sistem.guvenlik import kod_tara
    from beyin.geri_bildirim import degerlendir
    bilgi("uygulama_motoru", f"🔧 {gorev.get('baslik','?')}")
    kat = gorev.get("kategori","")
    ac  = gorev.get("aciklama","")
    sonuc = {"gorev_id": gorev.get("id"), "baslik": gorev.get("baslik"),
             "asamalar": [], "basarili": False, "puan": 0.0, "ozet": ""}
    if kat == "arastirma":
        from beyin.ogretici import hibrit_ogren, _aktif_kategori
        konu = ac.split()[0] if ac else "Python"
        ok = hibrit_ogren(konu, _aktif_kategori)
        sonuc.update({"basarili": ok, "puan": 7.0 if ok else 0, "ozet": f"Araştırıldı: {konu}"})
        return sonuc
    if kat in ("kod_yazma","test","optimizasyon"):
        kod = kod_yaz(f"Görev: {ac[:300]}\nSadece stdlib. print ile çıktı.")
        if not kod: sonuc["ozet"] = "Kod üretilemedi"; return sonuc
        temiz, bulgular = kod_tara(kod)
        if not temiz: sonuc["ozet"] = f"Güvenlik: {bulgular[:1]}"; return sonuc
        r = _sandbox(kod)
        if r["basarili"]:
            puan, yorum = degerlendir(ac, kod, r["cikti"])
            sonuc.update({"basarili": True, "puan": puan, "ozet": yorum})
            sonuc["asamalar"].append({"adim": "calistirma", "sonuc": f"✅ {r['sure']}sn"})
            if puan >= 7.0:
                try:
                    con = _db()
                    con.execute(
                        "INSERT OR REPLACE INTO beceri_kutuphanesi(isim,kod,puan,kategori,tarih) VALUES(?,?,?,?,?)",
                        (gorev.get("baslik","")[:50], kod, puan, kat, datetime.now().isoformat())
                    )
                    con.commit(); con.close()
                except Exception: pass
        else:
            sonuc["ozet"] = r["hata"][:150]; sonuc["puan"] = 2.0
        return sonuc
    # Analiz/bot planı
    from beyin.ai import sor
    cevap = sor(f"Görev: {ac[:300]}\nKısa analiz yap. Türkçe.", maks_sure=60)
    sonuc.update({"basarili": bool(cevap), "puan": 5.0 if cevap else 0, "ozet": cevap or "Yanıt yok"})
    return sonuc

# ── HEALTH CHECK ─────────────────────────────────────────
def cpu_yuzde() -> float:
    try:
        import re
        r = subprocess.run(["top","-bn1"], capture_output=True, text=True, timeout=5)
        for s in r.stdout.splitlines():
            if "cpu" in s.lower():
                m = re.search(r"([\d.]+)%?\s*idle", s)
                if m: return round(100 - float(m.group(1)), 1)
    except Exception: pass
    return 0.0

def ram_yuzde() -> float:
    try:
        r = subprocess.run(["free"], capture_output=True, text=True, timeout=5)
        for s in r.stdout.splitlines():
            if "Mem:" in s:
                p = s.split()
                if len(p) >= 3: return round(int(p[2])/int(p[1])*100, 1)
    except Exception: pass
    return 0.0

def sistem_saglik() -> dict:
    from sistem.telefon import sistem_durumu
    try:
        d = sistem_durumu()
        cpu = cpu_yuzde(); ram = ram_yuzde()
        uyarilar = []
        if cpu > 90:                    uyarilar.append(f"CPU %{cpu}")
        if ram > 90:                    uyarilar.append(f"RAM %{ram}")
        if d["sicaklik"] > CPU_KRITIK:  uyarilar.append(f"Sıcaklık {d['sicaklik']}°C")
        if d["pil_yuzde"] < 10 and not d["sarj"]: uyarilar.append(f"Kritik pil %{d['pil_yuzde']}")
        return {"cpu": cpu, "ram": ram, "pil": d["pil_yuzde"], "sarj": d["sarj"],
                "sicaklik": d["sicaklik"], "uyarilar": uyarilar, "saglikli": not uyarilar}
    except Exception as e:
        return {"cpu":0,"ram":0,"pil":50,"sarj":False,"sicaklik":35,"uyarilar":[str(e)],"saglikli":False}

def health_baslat():
    def _d():
        while True:
            try:
                s = sistem_saglik()
                if s["uyarilar"]:
                    for u in s["uyarilar"]: uyari("health", u)
            except Exception as e:
                hata("health", f"Health: {e}")
            time.sleep(120)
    threading.Thread(target=_d, daemon=True, name="nexus-health").start()
    bilgi("health", "Health check başlatıldı")
