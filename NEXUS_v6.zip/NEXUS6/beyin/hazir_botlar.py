"""
NEXUS v6 - Hazır Bot Sistemi

Kategori başına 5 bot, sadece 1 VeriDuzenleyici:
- web_tarama x5
- yazilim_kodlama x5
- haber_takip x5
- veri_analiz x5
- VeriDuzenleyici x1 (merkezi yazıcı)

Tüm botlar VeriDuzenleyici kuyruğuna yazar.
"""
from __future__ import annotations
import sys, os, time, random, threading, sqlite3, requests
from pathlib import Path
from datetime import datetime
from urllib.parse import quote

BASE = Path(__file__).parent.parent
sys.path.insert(0, str(BASE))
os.environ.setdefault("NEXUS_BASE", str(BASE))

from beyin.config import DEPO_DIR, BOTLAR_DIR
from beyin.logger import bilgi, hata, uyari, basari


# ── YARDIMCI ─────────────────────────────────────────────
_H = {"User-Agent": "NEXUS-Bot/6.0 (educational)"}

def _db_kaydet_kuyruk(bot_isim: str, kategori: str, konu: str, icerik: str, kaynak: str):
    """VeriDuzenleyici kuyruğuna yaz"""
    try:
        con = sqlite3.connect(str(DEPO_DIR/"nexus.db"), timeout=30)
        con.execute("PRAGMA journal_mode=WAL")
        con.execute(
            "INSERT INTO veri_kuyruğu(bot_isim,kategori,konu,icerik,kaynak,tarih) VALUES(?,?,?,?,?,?)",
            (bot_isim, kategori, konu, icerik[:2000], kaynak, datetime.now().isoformat())
        )
        con.commit(); con.close()
    except Exception as e:
        hata(bot_isim, f"Kuyruk: {e}")

def _ai_ozet(konu: str, icerik: str, kategori: str) -> str:
    """AI ile kısa özet çıkar"""
    try:
        from beyin.ai import sor
        return sor(
            f"Kategori: {kategori}\nKonu: {konu}\nVeri: {icerik[:800]}\n"
            "2-3 cümle özet yaz. Türkçe.",
            maks_sure=30
        ) or icerik[:300]
    except Exception:
        return icerik[:300]


# ── WEB TARAMA BOTLARI (5 adet) ───────────────────────────
WEB_SITELER = {
    "wiki": "https://{dil}.wikipedia.org/api/rest_v1/page/summary/{konu}",
    "so":   "https://api.stackexchange.com/2.3/search/advanced?order=desc&sort=votes&q={konu}&site=stackoverflow&pagesize=3",
    "gh":   "https://api.github.com/search/repositories?q={konu}+language:python&sort=stars&per_page=3",
    "devto": "https://dev.to/api/articles?tag={konu}&per_page=5",
    "hn":   "https://hn.algolia.com/api/v1/search?query={konu}&tags=story&hitsPerPage=3",
}

WEB_KONULAR = [
    "Python web scraping", "API development", "machine learning",
    "data science", "cybersecurity", "devops kubernetes",
    "javascript react", "database optimization", "microservices",
    "artificial intelligence", "blockchain solidity", "mobile development",
]

# URL katalog — botlar bulduğu URL'leri paylaşır
_url_katalog: list[str] = []
_url_lock = threading.Lock()

def _url_ekle(url: str):
    with _url_lock:
        if url not in _url_katalog:
            _url_katalog.append(url)
            if len(_url_katalog) > 1000:
                _url_katalog.pop(0)

def web_tarama_botu(bot_no: int):
    """Web tarama botu — konu araştırır, URL katalog tutar"""
    isim = f"WebTarayici{bot_no}"
    bilgi(isim, f"▶️ Web Tarama Botu #{bot_no} başladı")

    while True:
        try:
            konu = random.choice(WEB_KONULAR)
            bilgi(isim, f"🌐 Tarıyorum: {konu}")

            sonuclar = []

            # Wikipedia
            try:
                r = requests.get(
                    f"https://tr.wikipedia.org/api/rest_v1/page/summary/{quote(konu)}",
                    headers=_H, timeout=10
                )
                if r.status_code == 200:
                    d = r.json()
                    if d.get("extract"):
                        sonuclar.append(d["extract"][:500])
                        if d.get("content_urls", {}).get("desktop", {}).get("page"):
                            _url_ekle(d["content_urls"]["desktop"]["page"])
            except Exception: pass

            # Dev.to
            try:
                r = requests.get(
                    f"https://dev.to/api/articles?tag={quote(konu.replace(' ',''))}&per_page=3",
                    headers=_H, timeout=10
                )
                if r.status_code == 200:
                    for a in r.json()[:2]:
                        if a.get("title") and a.get("description"):
                            sonuclar.append(f"{a['title']}: {a['description'][:200]}")
                            if a.get("url"):
                                _url_ekle(a["url"])
            except Exception: pass

            # HackerNews
            try:
                r = requests.get(
                    f"https://hn.algolia.com/api/v1/search?query={quote(konu)}&tags=story&hitsPerPage=3",
                    headers=_H, timeout=10
                )
                if r.status_code == 200:
                    for h in r.json().get("hits", [])[:2]:
                        if h.get("title"):
                            sonuclar.append(h["title"])
                            if h.get("url"):
                                _url_ekle(h["url"])
            except Exception: pass

            if sonuclar:
                ham = " | ".join(sonuclar)
                ozet = _ai_ozet(konu, ham, "Teknoloji")
                _db_kaydet_kuyruk(isim, "Teknoloji", konu, ozet, "Web+DevTo+HN")
                basari(isim, f"✅ {konu} tarandı ({len(_url_katalog)} URL katalogda)")
            else:
                uyari(isim, f"Veri bulunamadı: {konu}")

        except Exception as e:
            hata(isim, f"Döngü: {e}")

        # Her bot farklı aralık — çakışma önle
        time.sleep(30 + bot_no * 5 + random.randint(0, 20))


# ── YAZILIM KODLAMA BOTLARI (5 adet) ──────────────────────
YAZILIM_KONULAR = [
    "Python asyncio coroutine", "decorator pattern Python",
    "context manager Python", "generator expression",
    "Python dataclass", "type hints mypy", "Python testing pytest",
    "SQLite Python CRUD", "HTTP requests Python",
    "JSON parsing Python", "error handling best practices",
    "Python logging module", "pathlib file handling",
    "threading multiprocessing", "Python packaging pip",
]

def yazilim_kodlama_botu(bot_no: int):
    """Yazılım botu — kod öğrenir, test eder, beceri kütüphanesine ekler"""
    isim = f"KodUstasi{bot_no}"
    bilgi(isim, f"▶️ Yazılım Kodlama Botu #{bot_no} başladı")

    while True:
        try:
            konu = random.choice(YAZILIM_KONULAR)
            bilgi(isim, f"💻 Kodlama: {konu}")

            from beyin.ai import sor, kod_yaz
            from sistem.guvenlik import kod_tara

            # 1. Öğren
            bilgi_metni = sor(
                f"Python'da '{konu}' konusunda:\n"
                "1. Ne işe yarar?\n2. Basit örnek kod (stdlib)\n3. Ne zaman kullanılır?\n"
                "Türkçe, kısa.",
                maks_sure=45
            )
            if bilgi_metni:
                _db_kaydet_kuyruk(isim, "Yazilim", konu, bilgi_metni, "AI-Yazilim")

            # 2. Çalışan kod yaz
            kod = kod_yaz(f"'{konu}' için basit Python örneği. Sadece stdlib. print ile göster.")
            if kod:
                temiz, _ = kod_tara(kod)
                if temiz:
                    # Sandbox test
                    import tempfile, shutil
                    tmp = tempfile.mkdtemp()
                    try:
                        dosya = str(Path(tmp)/"test.py")
                        with open(dosya,"w",encoding="utf-8") as f: f.write(kod)
                        import subprocess
                        r = subprocess.run([sys.executable, dosya],
                                           capture_output=True, text=True, timeout=10, cwd=tmp)
                        if r.returncode == 0:
                            # Beceri kütüphanesine ekle
                            try:
                                con = sqlite3.connect(str(DEPO_DIR/"nexus.db"), timeout=10)
                                con.execute("PRAGMA journal_mode=WAL")
                                con.execute(
                                    "INSERT OR REPLACE INTO beceri_kutuphanesi"
                                    "(isim,kod,puan,kategori,tarih) VALUES(?,?,?,?,?)",
                                    (konu[:50], kod, 8.0, "Yazilim", datetime.now().isoformat())
                                )
                                con.commit(); con.close()
                                basari(isim, f"✅ Beceri kaydedildi: {konu}")
                            except Exception: pass
                    finally:
                        shutil.rmtree(tmp, ignore_errors=True)

        except Exception as e:
            hata(isim, f"Döngü: {e}")

        time.sleep(45 + bot_no * 8 + random.randint(0, 30))


# ── HABER TAKİP BOTLARI (5 adet) ──────────────────────────
HABER_KONULAR = [
    "artificial intelligence news", "Python programming news",
    "cybersecurity news", "tech startup news", "open source news",
    "machine learning research", "web development trends",
    "cloud computing aws", "mobile app development",
    "data science trends",
]

def haber_takip_botu(bot_no: int):
    """Haber takip botu — güncel teknoloji haberlerini öğrenir"""
    isim = f"HaberTakipci{bot_no}"
    bilgi(isim, f"▶️ Haber Takip Botu #{bot_no} başladı")

    while True:
        try:
            konu = random.choice(HABER_KONULAR)
            bilgi(isim, f"📰 Haberler: {konu}")

            haberler = []

            # Dev.to son yazılar
            try:
                r = requests.get(
                    f"https://dev.to/api/articles?tag={quote(konu.split()[0])}&per_page=5",
                    headers=_H, timeout=10
                )
                if r.status_code == 200:
                    for a in r.json()[:3]:
                        if a.get("title") and a.get("description"):
                            haberler.append(f"📝 {a['title']}: {a.get('description','')[:150]}")
            except Exception: pass

            # HackerNews
            try:
                r = requests.get(
                    f"https://hn.algolia.com/api/v1/search_by_date?query={quote(konu)}&tags=story&hitsPerPage=5",
                    headers=_H, timeout=10
                )
                if r.status_code == 200:
                    for h in r.json().get("hits", [])[:3]:
                        if h.get("title"):
                            haberler.append(f"🔗 {h['title']}")
            except Exception: pass

            if haberler:
                ham = "\n".join(haberler)
                ozet = _ai_ozet(konu, ham, "Teknoloji")
                _db_kaydet_kuyruk(isim, "Teknoloji", f"Haber: {konu}", ozet, "DevTo+HN")
                basari(isim, f"✅ {len(haberler)} haber kaydedildi")

        except Exception as e:
            hata(isim, f"Döngü: {e}")

        time.sleep(60 + bot_no * 12 + random.randint(0, 30))


# ── VERİ ANALİZ BOTLARI (5 adet) ─────────────────────────
def veri_analiz_botu(bot_no: int):
    """Bilgi bankasını analiz eder, eksikleri tamamlar, zincir önerir"""
    isim = f"VeriAnalist{bot_no}"
    bilgi(isim, f"▶️ Veri Analiz Botu #{bot_no} başladı")

    while True:
        try:
            con = sqlite3.connect(str(DEPO_DIR/"nexus.db"), timeout=10)
            con.row_factory = sqlite3.Row

            # En az bilgi olan kategoriyi bul
            r = con.execute(
                "SELECT kategori, COUNT(*) as n FROM bilgi_bankasi "
                "GROUP BY kategori ORDER BY n ASC LIMIT 1"
            ).fetchone()
            con.close()

            if r:
                zayif_kat = r["kategori"] or "Yazilim"
                bilgi(isim, f"🔍 Zayıf kategori analiz: {zayif_kat} ({r['n']} kayıt)")

                from beyin.ai import sor
                oneri = sor(
                    f"'{zayif_kat}' kategorisinde {r['n']} bilgi var.\n"
                    f"Bu kategori için öğrenilmesi gereken 3 konu öner. "
                    f"Sadece konu isimlerini listele.",
                    maks_sure=30
                )
                if oneri:
                    _db_kaydet_kuyruk(isim, zayif_kat, f"Analiz: {zayif_kat}", oneri, "AI-Analiz")
                    # Önerilen konuları öğrenmeye al
                    konular = [k.strip().lstrip("0123456789.-) ") for k in oneri.splitlines() if k.strip()]
                    for k in konular[:2]:
                        if k:
                            from beyin.ogretici import hibrit_ogren
                            hibrit_ogren(k, zayif_kat, isim)

        except Exception as e:
            hata(isim, f"Döngü: {e}")

        time.sleep(120 + bot_no * 20 + random.randint(0, 60))


# ── TÜM BOTLARI BAŞLAT ────────────────────────────────────
def hepsini_baslat():
    """Tüm hazır botları başlat"""
    bilgi("hazir_botlar", "🚀 Hazır botlar başlatılıyor...")

    # Web Tarama x5
    for i in range(1, 6):
        t = threading.Thread(target=web_tarama_botu, args=(i,),
                             daemon=True, name=f"web-{i}")
        t.start()
        bilgi("hazir_botlar", f"▶️ WebTarayici{i} başlatıldı")

    # Yazılım Kodlama x5
    for i in range(1, 6):
        t = threading.Thread(target=yazilim_kodlama_botu, args=(i,),
                             daemon=True, name=f"kod-{i}")
        t.start()
        bilgi("hazir_botlar", f"▶️ KodUstasi{i} başlatıldı")

    # Haber Takip x5
    for i in range(1, 6):
        t = threading.Thread(target=haber_takip_botu, args=(i,),
                             daemon=True, name=f"haber-{i}")
        t.start()
        bilgi("hazir_botlar", f"▶️ HaberTakipci{i} başlatıldı")

    # Veri Analiz x5
    for i in range(1, 6):
        t = threading.Thread(target=veri_analiz_botu, args=(i,),
                             daemon=True, name=f"analiz-{i}")
        t.start()
        bilgi("hazir_botlar", f"▶️ VeriAnalist{i} başlatıldı")

    bilgi("hazir_botlar", "✅ 20 bot başlatıldı (Web x5, Kod x5, Haber x5, Analiz x5)")
    bilgi("hazir_botlar", "🗄️ VeriDuzenleyici merkezi yazıcı olarak çalışıyor")
