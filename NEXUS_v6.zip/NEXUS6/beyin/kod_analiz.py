"""NEXUS v6 - Kod Analizi"""
from __future__ import annotations
import threading, uuid
from pathlib import Path
from datetime import datetime
from beyin.config import BASE_DIR, DOCS_DIR
from beyin.logger import bilgi, hata

_onaylar: dict = {}
_onay_lock = threading.Lock()

def sistem_kodlarini_analiz_et() -> dict:
    from beyin.ai import sor
    bilgi("kod_analiz", "🔍 Analiz ediliyor...")
    sorunlar = []
    n = 0
    for kl in ["beyin","zeka","telegram","sistem"]:
        for d in (Path(BASE_DIR)/kl).glob("*.py"):
            if d.name.startswith("__"): continue
            try:
                kod = d.read_text(encoding="utf-8", errors="ignore")
                if len(kod) < 50: continue
                s = []
                if "except:" in kod: s.append("Belirsiz except")
                if kod.count("try:") > 0 and "finally:" not in kod: s.append("finally eksik")
                if s: sorunlar.append({"dosya": str(d.relative_to(BASE_DIR)), "sorunlar": s})
                n += 1
            except Exception: pass
    ai_oneri = None
    if sorunlar:
        try:
            ai_oneri = sor(
                f"{len(sorunlar)} dosyada sorun:\n{str(sorunlar[:3])[:400]}\n"
                "En kritik 3 sorun ve çözüm. Kısa Türkçe.",
                maks_sure=60
            )
        except Exception: pass
    sonuc = {"analiz_edilen": n, "sorunlu": len(sorunlar),
             "sorunlar": sorunlar[:5], "ai_oneri": ai_oneri or "Analiz tamamlandı"}
    try:
        Path(DOCS_DIR).mkdir(parents=True, exist_ok=True)
        (Path(DOCS_DIR)/"analiz.txt").write_text(str(sonuc), encoding="utf-8")
    except Exception: pass
    bilgi("kod_analiz", f"✅ {n} dosya — {len(sorunlar)} sorun")
    return sonuc

def onay_iste(dosya: str, oneri: str, fn=None) -> str:
    sid = uuid.uuid4().hex[:8]
    with _onay_lock: _onaylar[sid] = {"dosya": dosya, "oneri": oneri, "fn": fn}
    try:
        from telegram.bot import sor_onay
        sor_onay(f"🔧 {dosya}\n\n{oneri[:200]}\nUygulayayım mı?",
                 evet_fn=lambda: _uygula(sid),
                 hayir_fn=lambda: bilgi("kod_analiz", f"Reddedildi: {sid}"))
    except Exception as e: hata("kod_analiz", f"Onay: {e}")
    return sid

def _uygula(sid: str):
    with _onay_lock: onay = _onaylar.pop(sid, None)
    if onay and onay.get("fn"):
        try: onay["fn"]()
        except Exception as e: hata("kod_analiz", f"Uygulama: {e}")
