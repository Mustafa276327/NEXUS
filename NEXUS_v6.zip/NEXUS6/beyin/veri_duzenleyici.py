"""
NEXUS v6 - Veri Düzenleyici
- Tüm botlardan gelen veriyi sırayla işler (tek nokta)
- Race condition yok
- Kopyaları birleştirir
- DB'ye atomic yazar
- Her 5sn'de bir kuyruğu boşaltır
"""
from __future__ import annotations
import sqlite3, threading, time, hashlib
from datetime import datetime
from pathlib import Path
from beyin.config import DEPO_DIR
from beyin.logger import bilgi, hata, basari

_aktif = threading.Event()
_thread: threading.Thread | None = None


def _kopya_mi(con: sqlite3.Connection, konu: str, icerik: str) -> bool:
    """Aynı konu + benzer içerik var mı?"""
    mevcut = con.execute(
        "SELECT icerik FROM bilgi_bankasi WHERE konu=? ORDER BY id DESC LIMIT 1",
        (konu,)
    ).fetchone()
    if not mevcut:
        return False
    # İlk 100 karakter aynıysa kopya
    return mevcut[0][:100] == icerik[:100]


def _kuyrugu_isle():
    """Kuyruktaki bekleyen verileri DB'ye yaz"""
    con = sqlite3.connect(str(DEPO_DIR / "nexus.db"), timeout=30)
    con.execute("PRAGMA journal_mode=WAL")
    con.row_factory = sqlite3.Row
    try:
        bekleyenler = con.execute(
            "SELECT * FROM veri_kuyruğu WHERE islendi=0 ORDER BY id ASC LIMIT 20"
        ).fetchall()

        if not bekleyenler:
            return

        islendi = 0
        for kayit in bekleyenler:
            try:
                konu   = kayit["konu"]
                icerik = kayit["icerik"]
                kategori = kayit["kategori"]
                kaynak = kayit["kaynak"]
                bot    = kayit["bot_isim"]

                if not _kopya_mi(con, konu, icerik):
                    con.execute(
                        "INSERT INTO bilgi_bankasi(kategori,konu,icerik,kaynak,tarih,bot_isim) "
                        "VALUES(?,?,?,?,?,?)",
                        (kategori, konu, icerik[:2000], kaynak,
                         datetime.now().isoformat(), bot)
                    )
                    islendi += 1

                # Kuyruktan sil (işlendi)
                con.execute("UPDATE veri_kuyruğu SET islendi=1 WHERE id=?", (kayit["id"],))

            except Exception as e:
                hata("veri_duzenleyici", f"Kayıt hatası: {e}")

        con.commit()
        if islendi > 0:
            basari("veri_duzenleyici", f"✅ {islendi} yeni bilgi DB'ye eklendi")

    except Exception as e:
        con.rollback()
        hata("veri_duzenleyici", f"Kuyruk işleme: {e}")
    finally:
        con.close()


def _dongu():
    bilgi("veri_duzenleyici", "🗄️ Veri Düzenleyici başladı")
    while _aktif.is_set():
        try:
            _kuyrugu_isle()
        except Exception as e:
            hata("veri_duzenleyici", f"Döngü: {e}")
        time.sleep(5)  # Her 5sn


def baslat():
    global _thread
    if _thread and _thread.is_alive():
        return
    _aktif.set()
    _thread = threading.Thread(target=_dongu, daemon=True, name="nexus-veri")
    _thread.start()


def durdur():
    _aktif.clear()
    if _thread:
        _thread.join(timeout=10)
