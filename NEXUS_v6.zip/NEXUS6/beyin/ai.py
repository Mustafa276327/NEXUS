"""NEXUS v6 - AI Modülü (OpenRouter) — cache, retry, circuit breaker"""
from __future__ import annotations
import hashlib, re, time, threading, random
from typing import Optional
import requests
from beyin.config import OPENROUTER_API_KEY, OPENROUTER_URL, OPENROUTER_MODEL, AI_TIMEOUT
from beyin.logger import bilgi, hata, uyari

_INJECT = [r"ignore\s+previous", r"forget\s+previous", r"jailbreak",
           r"önceki\s+talimatları\s+unut"]

_cache: dict[str, tuple[str, float]] = {}
_cache_lock = threading.Lock()
CACHE_TTL = 600  # 10 dakika

def sanitize(t: str, maks: int = 3000) -> str:
    for k in _INJECT:
        t = re.sub(k, "[FİLTRE]", t, flags=re.IGNORECASE)
    return t[:maks]

def _cache_key(p: str, s: str, m: str) -> str:
    return hashlib.sha256(f"{m}:{s[:40]}:{p}".encode()).hexdigest()[:16]

def _cache_al(key: str) -> Optional[str]:
    with _cache_lock:
        if key in _cache:
            v, t = _cache[key]
            if time.monotonic() - t < CACHE_TTL:
                return v
            del _cache[key]
    return None

def _cache_kaydet(key: str, v: str):
    with _cache_lock:
        if len(_cache) >= 150:
            en_eski = min(_cache.items(), key=lambda x: x[1][1])[0]
            del _cache[en_eski]
        _cache[key] = (v, time.monotonic())

def _retry_edilebilir(e: str) -> bool:
    return not any(k in e for k in ["401","403","invalid_api_key","Unauthorized"])

def sor(
    prompt: str,
    sistem: str = "Sen NEXUS adlı otonom öğrenen Türkçe konuşan AI sistemisin. Kısa ve net cevap ver.",
    model: Optional[str] = None,
    sicaklik: float = 0.7,
    maks_sure: int = None,
    cid: str = "",
) -> Optional[str]:
    if maks_sure is None:
        maks_sure = AI_TIMEOUT
    _model = model or OPENROUTER_MODEL
    if not OPENROUTER_API_KEY:
        uyari("ai", "API key eksik", cid)
        return None

    ckey = _cache_key(prompt[:200], sistem[:40], _model)
    cached = _cache_al(ckey)
    if cached:
        bilgi("ai", "📦 Cache'den yanıt", cid)
        return cached

    from beyin.circuit_breaker import cb_al
    cb = cb_al("openrouter")

    def _post():
        r = requests.post(
            OPENROUTER_URL,
            headers={
                "Authorization": f"Bearer {OPENROUTER_API_KEY}",
                "Content-Type": "application/json",
                "HTTP-Referer": "https://nexus-ai.local",
                "X-Title": "NEXUS",
            },
            json={
                "model": _model,
                "messages": [
                    {"role": "system", "content": sistem},
                    {"role": "user",   "content": str(prompt)[:4000]},
                ],
                "temperature": sicaklik,
                "max_tokens": 1500,
            },
            timeout=maks_sure,
        )
        if r.status_code == 429:
            raise Exception("RateLimit")
        if r.status_code == 402:
            raise Exception("402_Payment")
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"].strip()

    bekleme = 3.0
    for deneme in range(1, 6):
        try:
            cevap = cb.cagir(_post)
            if cevap:
                _cache_kaydet(ckey, cevap)
            bilgi("ai", f"✅ Yanıt (deneme {deneme})", cid)
            return cevap or None
        except RuntimeError:
            uyari("ai", "Devre açık — istek reddedildi", cid)
            return None
        except Exception as e:
            es = str(e)
            if not _retry_edilebilir(es):
                hata("ai", f"Retry edilemez: {es[:80]}", cid)
                return None
            if "RateLimit" in es:
                bekleme = min(bekleme * 3, 120)
            uyari("ai", f"Hata (deneme {deneme}/5): {es[:80]}", cid)
            if deneme == 5:
                return None
            time.sleep(bekleme + random.uniform(0, bekleme * 0.3))
            bekleme = min(bekleme * 2, 60)
    return None

def kod_yaz(gorev: str) -> Optional[str]:
    return sor(
        f"Görev: {gorev[:400]}\n"
        "Sadece stdlib kullan. Düz Python kodu yaz (markdown yok). "
        "Hata yakala. print ile çıktı ver.",
        sicaklik=0.2,
    )

def isim_sec(uzmanlik: str) -> Optional[str]:
    c = sor(f"'{uzmanlik}' için kısa bot ismi. Sadece ismi yaz.", sicaklik=0.9)
    if c:
        i = re.sub(r"[^a-zA-Z0-9_]", "", c.strip().split()[0])
        return i[:20] if i else None
    return None
