"""NEXUS v6 - Circuit Breaker"""
from __future__ import annotations
import threading, time
from enum import Enum
from typing import Callable, Any, Optional

class Durum(Enum):
    KAPALI = "KAPALI"; ACIK = "ACIK"; YARI_ACIK = "YARI_ACIK"

class CircuitBreaker:
    def __init__(self, isim: str, hata_esigi: int = 5,
                 bekleme: int = 60, yari_acik_deneme: int = 2):
        self.isim = isim
        self.hata_esigi = hata_esigi
        self.bekleme = bekleme
        self.yari_acik_deneme = yari_acik_deneme
        self._durum = Durum.KAPALI
        self._hata = 0; self._yari_basari = 0
        self._acilis: Optional[float] = None
        self._lock = threading.RLock()
        self.toplam = 0; self.basarili = 0; self.basarisiz = 0
        self.son_hata = ""; self.acilma = 0

    @property
    def durum(self) -> Durum:
        with self._lock:
            if self._durum == Durum.ACIK and self._acilis:
                if time.monotonic() - self._acilis >= self.bekleme:
                    self._gecis(Durum.YARI_ACIK)
            return self._durum

    def _gecis(self, yeni: Durum):
        self._durum = yeni
        if yeni == Durum.ACIK:
            self._acilis = time.monotonic(); self.acilma += 1
            try:
                from beyin.logger import uyari
                uyari("cb", f"⚡ [{self.isim}] AÇILDI")
            except Exception: pass
        elif yeni == Durum.KAPALI:
            self._hata = 0; self._yari_basari = 0; self._acilis = None
            try:
                from beyin.logger import bilgi
                bilgi("cb", f"✅ [{self.isim}] KAPANDI")
            except Exception: pass

    def cagir(self, fn: Callable, *args, **kwargs) -> Any:
        with self._lock:
            if self.durum == Durum.ACIK:
                raise RuntimeError(f"[CB:{self.isim}] Devre açık")
            self.toplam += 1
        try:
            s = fn(*args, **kwargs)
            with self._lock:
                self.basarili += 1
                if self._durum == Durum.YARI_ACIK:
                    self._yari_basari += 1
                    if self._yari_basari >= self.yari_acik_deneme:
                        self._gecis(Durum.KAPALI)
                else:
                    self._hata = max(0, self._hata - 1)
            return s
        except Exception as e:
            with self._lock:
                self.basarisiz += 1; self.son_hata = str(e)[:150]
                if self._durum == Durum.YARI_ACIK:
                    self._gecis(Durum.ACIK)
                else:
                    self._hata += 1
                    if self._hata >= self.hata_esigi:
                        self._gecis(Durum.ACIK)
            raise

    def metrik(self) -> dict:
        with self._lock:
            return {"isim": self.isim, "durum": self._durum.value,
                    "hata": self._hata, "toplam": self.toplam,
                    "basarili": self.basarili, "basarisiz": self.basarisiz,
                    "acilma": self.acilma, "son_hata": self.son_hata}

_reg: dict[str, CircuitBreaker] = {}
_reg_lock = threading.Lock()

def cb_al(isim: str, **kw) -> CircuitBreaker:
    with _reg_lock:
        if isim not in _reg:
            _reg[isim] = CircuitBreaker(isim, **kw)
        return _reg[isim]

def tum_metrikler() -> list:
    with _reg_lock:
        return [cb.metrik() for cb in _reg.values()]

# Hazır CB'ler
cb_al("openrouter", hata_esigi=5, bekleme=120)
cb_al("telegram",   hata_esigi=5, bekleme=60)
cb_al("github",     hata_esigi=3, bekleme=300)
