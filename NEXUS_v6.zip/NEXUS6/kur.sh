#!/bin/bash
echo "╔════════════════════════════════════╗"
echo "║  ⚡ NEXUS v6.0.0 KURULUM ⚡        ║"
echo "╚════════════════════════════════════╝"
NEXUS_DIR="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$NEXUS_DIR"/{beyin,zeka,telegram,sistem,panel,depo,kayit,yedek,docs}
mkdir -p "$NEXUS_DIR"/botlar/{aktif,arsiv,fail,sandbox,web_tarama,yazilim,veri,haber,analiz}
for d in beyin zeka telegram sistem panel; do
    [ ! -f "$NEXUS_DIR/$d/__init__.py" ] && touch "$NEXUS_DIR/$d/__init__.py"
done
echo "📦 Paketler..."
pkg update -y 2>/dev/null || true
pkg install -y python git tmux termux-api 2>/dev/null || true
pip install requests --quiet --break-system-packages 2>/dev/null || pip install requests --quiet 2>/dev/null || true
if [ ! -f "$NEXUS_DIR/.env" ]; then
    cp "$NEXUS_DIR/.env.example" "$NEXUS_DIR/.env"
fi
grep -q "NEXUS_BASE" "$NEXUS_DIR/.env" || echo "" >> "$NEXUS_DIR/.env"
sed -i "s|NEXUS_BASE=.*|NEXUS_BASE=$NEXUS_DIR|" "$NEXUS_DIR/.env" 2>/dev/null
grep -q "NEXUS_BASE" "$NEXUS_DIR/.env" || echo "NEXUS_BASE=$NEXUS_DIR" >> "$NEXUS_DIR/.env"
echo ""
echo "✅ Kurulum tamamlandı!"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "⚠️  .env dosyasını doldur:"
echo "   nano $NEXUS_DIR/.env"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🚀 BAŞLAT: cd $NEXUS_DIR && python panel.py"
echo ""
rm -f "$0"
