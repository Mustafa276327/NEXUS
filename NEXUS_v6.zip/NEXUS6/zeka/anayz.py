"""NEXUS v6 - AnaYZ (sistem= parametresi, döngü koruması)"""
from __future__ import annotations
import json, threading, time
from datetime import datetime
from pathlib import Path
from typing import Optional, Tuple, Dict
from beyin.config import DOCS_DIR, DEPO_DIR, AI_TIMEOUT
from beyin.logger import bilgi, hata, karar, anayz as log_anayz
from beyin.veritabani import baglanti

_don: list = []
_don_lock = threading.Lock()

class AnaYZ:
    def __init__(self):
        self._isim: Optional[str] = None
        self._isim_lock = threading.Lock()
        self.komite = {
            "analist":        "Sen NEXUS sisteminin teknik analistisisin. Net analiz yap. Türkçe.",
            "degerlendirici": "Sen NEXUS sisteminin risk değerlendiricisin. Kısa yorum. Türkçe.",
            "karar_verici":   "Sen NEXUS sisteminin karar vericisisin. Net karar ver. Türkçe.",
        }

    @property
    def isim(self) -> str:
        with self._isim_lock:
            if self._isim is None:
                self._isim = self._isim_yukle()
        return self._isim

    def _isim_yukle(self) -> str:
        d = DEPO_DIR / "sistem_ismi.txt"
        if d.exists():
            s = d.read_text(encoding="utf-8").strip()
            if s: return s
        try:
            from beyin.ai import sor
            c = sor("Otonom öğrenen AI sistemi için güçlü kısa isim. Sadece ismi yaz.",
                    sistem="Sen isim üreticisisin.", sicaklik=0.9, maks_sure=20)
            isim = (c or "I.J.ADA").strip().split("\n")[0][:20]
        except Exception:
            isim = "I.J.ADA"
        DEPO_DIR.mkdir(parents=True, exist_ok=True)
        d.write_text(isim, encoding="utf-8")
        log_anayz("anayz", f"🌟 Sistem adı: {isim}")
        return isim

    def _don_kontrol(self, konu: str) -> bool:
        with _don_lock:
            simdi = time.time()
            _don[:] = [(k,t) for k,t in _don if simdi-t < 3600]
            if any(k == konu for k,t in _don):
                bilgi("anayz", f"Döngü koruması: {konu[:40]}")
                return True
            _don.append((konu, simdi))
        return False

    def oyla(self, konu: str, baglam: str = "") -> Tuple[bool, Dict]:
        from beyin.ai import sor, sanitize
        if self._don_kontrol(konu):
            return False, {"not": "döngü koruması"}
        log_anayz("anayz", f"🗳️ {konu[:50]}")
        oylar: Dict = {}
        for uye, sistem_metni in self.komite.items():
            c = sor(
                f"Konu: {str(konu)[:150]}\nBağlam: {sanitize(baglam,200)}\n"
                "EVET mi HAYIR mı? İlk kelime EVET/HAYIR, sonra tek cümle.",
                sistem=sistem_metni, sicaklik=0.3, maks_sure=30,
            )
            evet = (c or "").strip().upper().startswith("EVET")
            oylar[uye] = {"karar": evet, "gerekce": (c or "")[:100]}
            bilgi("anayz", f"  {uye}: {'✅' if evet else '❌'}")
        evet_n = sum(1 for o in oylar.values() if o["karar"])
        sonuc = evet_n >= 2
        con = baglanti()
        try:
            con.execute(
                "INSERT INTO kararlar(karar,gerekce,oylama_sonucu,tarih) VALUES(?,?,?,?)",
                (str(konu)[:150], json.dumps(oylar,ensure_ascii=False),
                 f"{evet_n}/3 {'ONAY' if sonuc else 'RED'}", datetime.now().isoformat())
            )
            con.commit()
        except Exception as e:
            con.rollback(); hata("anayz", f"Karar DB: {e}")
        finally: con.close()
        karar("anayz", f"{'✅ ONAY' if sonuc else '❌ RED'} ({evet_n}/3)")
        return sonuc, oylar

    def anayasa_yaz(self) -> dict:
        from beyin.ai import sor
        d = DOCS_DIR / "anayasa.json"
        if d.exists():
            try: return json.loads(d.read_text(encoding="utf-8"))
            except Exception: pass
        c = sor(
            f"{self.isim} için 5 maddelik anayasa. JSON:\n"
            '{"maddeler":[{"no":1,"baslik":"...","icerik":"..."}]}',
            sistem=f"Sen {self.isim} kurucu AnaYZ'sisin.",
            maks_sure=AI_TIMEOUT,
        )
        if not c: return {}
        try:
            m = json.loads(c[c.find('{'):c.rfind('}')+1])
        except Exception: return {}
        DOCS_DIR.mkdir(parents=True, exist_ok=True)
        d.write_text(json.dumps(m, ensure_ascii=False, indent=2), encoding="utf-8")
        log_anayz("anayz", "✅ Anayasa yazıldı")
        return m

_inst: Optional[AnaYZ] = None
_inst_lock = threading.Lock()

def anayz_al() -> AnaYZ:
    global _inst
    with _inst_lock:
        if _inst is None: _inst = AnaYZ()
    return _inst
