"""NEXUS v6 - Guvenlik"""
import os, re, ast, base64, tempfile, subprocess, shutil, sys
from typing import Tuple, List
from beyin.logger import bilgi, hata, uyari

_PAT = [
    r"os\.system\s*\(",
    r"shutil\.rmtree\s*\(\s*['\"][/]",
    r"open\s*\(\s*['\"][/]etc",
    r"__import__\s*\(",
    r"eval\s*\(",
    r"exec\s*\(",
    r"ctypes",
]

def kod_tara(kod: str) -> Tuple[bool, List[str]]:
    if not kod or not kod.strip():
        return False, ["Bos kod"]
    bulgular = []
    gen = kod
    for m in re.compile(r'base64\.b64decode\s*\(\s*["\']([A-Za-z0-9+/=]+)["\']\)').finditer(kod):
        try: gen += "\n" + base64.b64decode(m.group(1)).decode("utf-8","ignore")
        except Exception: pass
    for k in _PAT:
        try:
            if re.findall(k, gen, re.IGNORECASE): bulgular.append(f"Regex:{k[:20]}")
        except re.error: pass
    try:
        for node in ast.walk(ast.parse(kod)):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
                if node.func.id in ("exec","eval","compile","__import__"):
                    bulgular.append(f"AST:{node.func.id}()")
    except SyntaxError as e:
        bulgular.append(f"Syntax:{e}")
        return False, bulgular
    if bulgular:
        uyari("guvenlik", f"Sorun: {len(bulgular)}"); return False, bulgular
    bilgi("guvenlik", "Temiz"); return True, []
