import subprocess, json
from typing import Optional
from beyin.logger import uyari

def _termux(cmd, timeout=8) -> Optional[str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.stdout if r.returncode == 0 else None
    except Exception as e:
        uyari("telefon", f"{cmd[0]}: {e}")
        return None

def pil() -> dict:
    c = _termux(["termux-battery-status"])
    if c:
        try:
            d = json.loads(c)
            return {"yuzde": d.get("percentage", d.get("level", 50)),
                    "sarj": d.get("status") in ("CHARGING","FULL"),
                    "sicaklik": float(d.get("temperature", 35))}
        except Exception: pass
    return {"yuzde": 50, "sarj": False, "sicaklik": 35.0}

def wifi() -> dict:
    c = _termux(["termux-wifi-connectioninfo"])
    if c:
        try:
            d = json.loads(c)
            return {"bagli": d.get("supplicant_state") == "COMPLETED",
                    "ssid": d.get("ssid", "").strip('"')}
        except Exception: pass
    return {"bagli": False, "ssid": ""}

def sistem_durumu() -> dict:
    p = pil(); w = wifi()
    return {"pil_yuzde": p["yuzde"], "sarj": p["sarj"],
            "wifi": w["bagli"], "ssid": w["ssid"],
            "sicaklik": p.get("sicaklik", 35.0)}
