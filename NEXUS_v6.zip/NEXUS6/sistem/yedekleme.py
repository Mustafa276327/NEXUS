import base64, json, sqlite3, requests
from datetime import datetime
from pathlib import Path
from beyin.config import GITHUB_TOKEN, GITHUB_USER, GITHUB_REPO, DEPO_DIR, DOCS_DIR
from beyin.logger import bilgi, hata, uyari, basari

_API = "https://api.github.com"
def _hdr(): return {"Authorization": f"token {GITHUB_TOKEN}", "Accept": "application/vnd.github.v3+json"}

def _repo_olustur() -> bool:
    if not GITHUB_TOKEN or not GITHUB_USER:
        uyari("yedekleme", "GitHub ayari eksik"); return False
    try:
        r = requests.get(f"{_API}/repos/{GITHUB_USER}/{GITHUB_REPO}", headers=_hdr(), timeout=20)
        if r.status_code == 200: return True
        r = requests.post(f"{_API}/user/repos", headers=_hdr(),
            json={"name": GITHUB_REPO, "private": True, "auto_init": True}, timeout=20)
        return r.status_code in (201, 422)
    except Exception as e:
        hata("yedekleme", f"Repo: {e}"); return False

def _yukle(yol: str, icerik: bytes, mesaj: str):
    try:
        r = requests.get(f"{_API}/repos/{GITHUB_USER}/{GITHUB_REPO}/contents/{yol}",
                        headers=_hdr(), timeout=20)
        sha = r.json().get("sha") if r.status_code == 200 else None
        payload = {"message": mesaj, "content": base64.b64encode(icerik).decode(),
                   "committer": {"name": "NEXUS", "email": "nexus@ai.local"}}
        if sha: payload["sha"] = sha
        requests.put(f"{_API}/repos/{GITHUB_USER}/{GITHUB_REPO}/contents/{yol}",
                    headers=_hdr(), json=payload, timeout=60)
    except Exception as e:
        hata("yedekleme", f"Yukleme: {e}")

def yedek_al():
    if not _repo_olustur(): return False
    bilgi("yedekleme", "Yedek basliyor...")
    zaman = datetime.now().strftime("%Y%m%d_%H%M%S")
    try:
        con = sqlite3.connect(str(DEPO_DIR/"nexus.db"))
        con.row_factory = sqlite3.Row
        data = {}
        for t in ["botlar","bilgi_bankasi","kararlar","beceri_kutuphanesi"]:
            try: data[t] = [dict(r) for r in con.execute(f"SELECT * FROM {t}").fetchall()]
            except Exception: pass
        con.close()
        _yukle(f"yedekler/{zaman}/db.json",
               json.dumps(data, ensure_ascii=False, indent=2, default=str).encode(),
               f"Yedek {zaman}")
    except Exception as e:
        hata("yedekleme", f"DB: {e}")
    for d in [Path(DOCS_DIR)]:
        if d.exists():
            for f in d.rglob("*"):
                if f.is_file() and f.suffix in (".json",".txt",".md"):
                    try: _yukle(f"yedekler/{zaman}/docs/{f.name}", f.read_bytes(), f"Docs {f.name}")
                    except Exception: pass
    basari("yedekleme", f"Yedek tamamlandi: {zaman}")
    try:
        from telegram.bot import mesaj_gonder
        mesaj_gonder(f"Yedek: {zaman}\ngithub.com/{GITHUB_USER}/{GITHUB_REPO}")
    except Exception: pass
    return True
