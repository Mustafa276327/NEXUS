"""
NEXUS v6 - Telegram Bot
- Kalıcı offset
- Düzenli mesaj formatı
- Şarj: sadece %30/%15, 10dk auto-reply
- Flood control + yetki
- Tüm komutlar
"""
from __future__ import annotations
import threading, time, uuid
from typing import Optional, Callable
import requests
from beyin.config import TELEGRAM_TOKEN, TELEGRAM_CHAT_ID
from beyin.logger import bilgi, hata, uyari
from beyin.veritabani import tg_offset_al, tg_offset_kaydet

_BASE = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}"
_dur  = threading.Event()
_thread: Optional[threading.Thread] = None
_flood: dict[str, float] = {}
FLOOD_LIMIT = 2.0

_onaylar: dict[str, dict] = {}
_onay_lock = threading.Lock()
_komutlar: dict[str, Callable] = {}


def _token_ok() -> bool:
    return bool(TELEGRAM_TOKEN and TELEGRAM_TOKEN not in ("", "BURAYA_BOT_TOKEN_YAZ"))

def _yetkili(cid: str) -> bool:
    return str(cid) == str(TELEGRAM_CHAT_ID)

def mesaj_gonder(metin: str, chat_id: Optional[str] = None) -> bool:
    if not _token_ok(): return False
    cid = str(chat_id or TELEGRAM_CHAT_ID)
    if not cid or cid == "BURAYA_CHAT_ID_YAZ": return False
    bekleme = 2.0
    for _ in range(5):
        try:
            r = requests.post(
                f"{_BASE}/sendMessage",
                json={"chat_id": cid, "text": metin[:4096], "parse_mode": "HTML"},
                timeout=30,
            )
            if r.status_code == 429:
                time.sleep(bekleme); bekleme *= 2; continue
            return r.json().get("ok", False)
        except Exception as e:
            hata("telegram", f"Gonderme: {e}")
            time.sleep(bekleme); bekleme *= 2
    return False

def sor_onay(soru: str, evet_fn: Callable = None, hayir_fn: Callable = None,
             oto_kadar: bool = False, oto_sure: int = 600) -> str:
    sid = uuid.uuid4().hex[:8]
    with _onay_lock:
        _onaylar[sid] = {"soru": soru, "evet": evet_fn, "hayir": hayir_fn}
    mesaj_gonder(
        f"❓ <b>NEXUS Soruyor [{sid}]</b>\n\n{soru}\n\n"
        f"<code>/evet_{sid}</code> veya <code>/hayir_{sid}</code>\n"
        f"<i>(10dk cevap gelmezse otomatik karar)</i>"
    )
    def _oto():
        time.sleep(oto_sure)
        with _onay_lock:
            onay = _onaylar.pop(sid, None)
        if not onay: return
        fn = onay["evet"] if oto_kadar else onay.get("hayir")
        if fn:
            try: fn()
            except Exception: pass
        mesaj_gonder(
            f"⏰ <b>Otomatik Karar [{sid}]</b>\n"
            f"10dk cevap gelmedi.\n"
            f"Karar: {'✅ EVET' if oto_kadar else '❌ HAYIR'}"
        )
    threading.Thread(target=_oto, daemon=True).start()
    return sid

def _reg(isim: str):
    def d(fn): _komutlar[isim] = fn; return fn
    return d

# ── KOMUTLAR ─────────────────────────────────────────────
@_reg("/durum")
def _(arg):
    try:
        from sistem.telefon import sistem_durumu
        from beyin.gorev_uretici import sistem_saglik
        d = sistem_durumu(); s = sistem_saglik()
        pil_r = "✅" if d["pil_yuzde"] >= 50 else "⚠️" if d["pil_yuzde"] >= 20 else "🚨"
        return (
            f"📊 <b>NEXUS v6 Durum</b>\n{'─'*22}\n"
            f"{pil_r} Pil: <b>%{d['pil_yuzde']}</b> {'🔌' if d['sarj'] else '🔋'}\n"
            f"🌡️ Sıcaklık: <b>{d['sicaklik']}°C</b>\n"
            f"📶 WiFi: {'✅ ' + d['ssid'] if d['wifi'] else '❌'}\n"
            f"🖥️ CPU: %{s.get('cpu',0):.0f} RAM: %{s.get('ram',0):.0f}\n"
            f"{'⚠️ ' + ' | '.join(s['uyarilar']) if s.get('uyarilar') else '✅ Sağlıklı'}"
        )
    except Exception as e: return f"❌ {e}"

@_reg("/botlar")
def _(arg):
    try:
        from beyin.veritabani import sorgu
        botlar = sorgu(
            "SELECT isim,rutbe,uzmanlik,profesyonellik_puani "
            "FROM botlar WHERE aktif=1 ORDER BY profesyonellik_puani DESC"
        )
        if not botlar: return "🤖 Henüz dinamik bot yok."
        return (
            f"🤖 <b>Botlar ({len(botlar)})</b>\n{'─'*22}\n" +
            "\n".join(f"• <b>{b['isim']}</b> [{b['rutbe']}] — {b['uzmanlik'] or '-'} {b['profesyonellik_puani']:.0f}p"
                      for b in botlar)
        )
    except Exception as e: return f"❌ {e}"

@_reg("/bilgi")
def _(arg):
    try:
        from beyin.veritabani import sorgu
        toplam = sorgu("SELECT COUNT(*) as n FROM bilgi_bankasi")[0]["n"]
        kats   = sorgu("SELECT kategori, COUNT(*) as n FROM bilgi_bankasi GROUP BY kategori ORDER BY n DESC LIMIT 5")
        son    = sorgu("SELECT konu,kategori FROM bilgi_bankasi ORDER BY id DESC LIMIT 5")
        kat_str = " | ".join(f"{k['kategori']}:{k['n']}" for k in kats)
        return (
            f"📚 <b>Bilgi Bankası</b> — {toplam} kayıt\n{'─'*22}\n"
            f"📊 {kat_str}\n\n"
            f"<b>Son öğrenilenler:</b>\n" +
            "\n".join(f"• [{b['kategori']}] {b['konu'][:40]}" for b in son)
        )
    except Exception as e: return f"❌ {e}"

@_reg("/rapor")
def _(arg):
    try:
        from beyin.veritabani import sorgu
        from beyin.geri_bildirim import ortalama_puan, gelisim_trendi
        bilgi_n = sorgu("SELECT COUNT(*) as n FROM bilgi_bankasi")[0]["n"]
        bot_n   = sorgu("SELECT COUNT(*) as n FROM botlar WHERE aktif=1")[0]["n"]
        gorev_n = sorgu("SELECT COUNT(*) as n FROM uretilen_gorevler WHERE durum='tamamlandi'")[0]["n"]
        bc_n    = sorgu("SELECT COUNT(*) as n FROM beceri_kutuphanesi")[0]["n"]
        kuyrukt = sorgu("SELECT COUNT(*) as n FROM veri_kuyruğu WHERE islendi=0")[0]["n"]
        return (
            f"📋 <b>NEXUS v6 Rapor</b>\n{'─'*22}\n"
            f"📚 Bilgi: <b>{bilgi_n}</b>\n"
            f"🤖 Dinamik Bot: <b>{bot_n}</b>\n"
            f"✅ Görev: <b>{gorev_n}</b>\n"
            f"💾 Beceri: <b>{bc_n}</b>\n"
            f"⏳ Kuyruk: <b>{kuyrukt}</b> bekliyor\n"
            f"⭐ Ort Puan: <b>{ortalama_puan()}/10</b>\n"
            f"📈 {gelisim_trendi()}"
        )
    except Exception as e: return f"❌ {e}"

@_reg("/gorevler")
def _(arg):
    try:
        from beyin.veritabani import sorgu
        bek = sorgu("SELECT baslik,kategori FROM uretilen_gorevler WHERE durum='bekliyor' ORDER BY id DESC LIMIT 5")
        tam = sorgu("SELECT baslik,puan FROM uretilen_gorevler WHERE durum='tamamlandi' ORDER BY id DESC LIMIT 5")
        s = [f"📋 <b>Görevler</b>\n{'─'*22}"]
        if bek:
            s.append("⏳ <b>Bekleyen:</b>")
            for g in bek: s.append(f"  • [{g['kategori']}] {g['baslik'][:45]}")
        if tam:
            s.append("\n✅ <b>Son Tamamlanan:</b>")
            for g in tam: s.append(f"  • ⭐{g['puan']:.1f} {g['baslik'][:45]}")
        return "\n".join(s)
    except Exception as e: return f"❌ {e}"

@_reg("/ogren")
def _(arg):
    if not arg: return "Kullanım: /ogren [konu]"
    try:
        from beyin.ogretici import hibrit_ogren, _aktif_kategori
        threading.Thread(target=hibrit_ogren, args=(arg, _aktif_kategori), daemon=True).start()
        return f"📚 <b>{arg}</b> öğreniliyor...\nWiki + SO + GitHub + AI"
    except Exception as e: return f"❌ {e}"

@_reg("/kategori")
def _(arg):
    try:
        from beyin.ogretici import _aktif_kategori
        from beyin.config import KATEGORILER
        from beyin.veritabani import sorgu
        s = [f"📂 <b>Aktif Kategori: {_aktif_kategori}</b>\n{'─'*22}"]
        for k, v in KATEGORILER.items():
            n = sorgu("SELECT COUNT(*) as n FROM bilgi_bankasi WHERE kategori=?", (k,))
            s.append(f"{'▶️' if k == _aktif_kategori else '•'} {k}: {n[0]['n']} bilgi")
        return "\n".join(s)
    except Exception as e: return f"❌ {e}"

@_reg("/beceriler")
def _(arg):
    try:
        from beyin.veritabani import sorgu
        b = sorgu("SELECT isim,puan,kullanim_sayisi FROM beceri_kutuphanesi ORDER BY puan DESC LIMIT 8")
        if not b: return "💾 Henüz beceri yok."
        return (
            f"💾 <b>Beceri Kütüphanesi</b>\n{'─'*22}\n" +
            "\n".join(f"• {x['isim'][:35]} ⭐{x['puan']:.1f} ({x['kullanim_sayisi']}x)" for x in b)
        )
    except Exception as e: return f"❌ {e}"

@_reg("/trend")
def _(arg):
    try:
        from beyin.geri_bildirim import gelisim_trendi, ortalama_puan
        return f"📈 <b>Gelişim</b>\n{'─'*22}\n{gelisim_trendi()}\n⭐ Ort: {ortalama_puan()}/10"
    except Exception as e: return f"❌ {e}"

@_reg("/analiz")
def _(arg):
    try:
        from beyin.kod_analiz import sistem_kodlarini_analiz_et
        threading.Thread(target=lambda: _analiz_bildir(), daemon=True).start()
        return "🔍 Kod analizi başlatıldı..."
    except Exception as e: return f"❌ {e}"

def _analiz_bildir():
    try:
        from beyin.kod_analiz import sistem_kodlarini_analiz_et
        r = sistem_kodlarini_analiz_et()
        mesaj_gonder(
            f"🔍 <b>Analiz Sonucu</b>\n{'─'*22}\n"
            f"📁 {r.get('analiz_edilen',0)} dosya analiz edildi\n"
            f"⚠️ {r.get('sorunlu',0)} sorunlu\n\n"
            f"💡 {r.get('ai_oneri','')[:250]}"
        )
    except Exception as e: mesaj_gonder(f"❌ Analiz: {e}")

@_reg("/yedek")
def _(arg):
    try:
        from sistem.yedekleme import yedek_al
        threading.Thread(target=yedek_al, daemon=True).start()
        return "💾 Yedek başlatıldı..."
    except Exception as e: return f"❌ {e}"

@_reg("/flag")
def _(arg):
    if not arg: return "Kullanım: /flag [isim] [on/off]"
    p = arg.split()
    if len(p) != 2: return "Kullanım: /flag [isim] [on/off]"
    try:
        from beyin.feature_flags import toggle
        d = p[1].lower() in ("on","1","true","acik")
        toggle(p[0], d)
        return f"✅ {p[0]} = {'açık 🟢' if d else 'kapalı 🔴'}"
    except Exception as e: return f"❌ {e}"

@_reg("/yardim")
@_reg("/help")
def _(arg):
    return (
        "🤖 <b>NEXUS v6 Komutları</b>\n"
        f"{'─'*24}\n"
        "📊 /durum — Sistem durumu\n"
        "🤖 /botlar — Bot listesi\n"
        "📚 /bilgi — Bilgi bankası\n"
        "📋 /rapor — Tam rapor\n"
        "📋 /gorevler — Görevler\n"
        "📂 /kategori — Öğrenme kategorileri\n"
        "💾 /beceriler — Beceri listesi\n"
        "📈 /trend — Gelişim trendi\n"
        f"{'─'*24}\n"
        "📚 /ogren [konu] — Öğret\n"
        "🔍 /analiz — Kod analizi\n"
        "💾 /yedek — GitHub yedeği\n"
        "⚙️ /flag [isim] [on/off]\n"
        f"{'─'*24}\n"
        "Serbest metin → AI yanıtlar"
    )

# ── DÖNGÜ ────────────────────────────────────────────────
def _isle(metin: str, chat_id: str) -> Optional[str]:
    if not _yetkili(chat_id): return "⛔ Yetkisiz"
    if len(metin) > 600: return "⚠️ Çok uzun (max 600)"
    p = metin.strip().split(None, 1)
    cmd = p[0].lower(); arg = p[1].strip() if len(p) > 1 else ""

    # Onay komutları
    if cmd.startswith("/evet_") or cmd.startswith("/hayir_"):
        sid = cmd[6:] if cmd.startswith("/evet_") else cmd[7:]
        with _onay_lock: onay = _onaylar.pop(sid, None)
        if not onay: return "Geçersiz/süresi dolmuş."
        fn = onay["evet"] if cmd.startswith("/evet_") else onay.get("hayir")
        if fn:
            try: fn()
            except Exception as e: return f"❌ {e}"
        return f"{'✅ Onaylandı' if cmd.startswith('/evet_') else '❌ Reddedildi'}"

    fn = _komutlar.get(cmd)
    if fn:
        try: return fn(arg) or "✅"
        except Exception as e:
            hata("telegram", f"Komut [{cmd}]: {e}")
            return f"❌ {e}"

    try:
        from beyin.ai import sor, sanitize
        return sor(sanitize(metin, 400)) or "Anlayamadım. /yardim"
    except Exception as e: return f"❌ {e}"

def _guncelleme() -> list:
    if not _token_ok(): return []
    son = tg_offset_al()
    try:
        r = requests.get(f"{_BASE}/getUpdates",
                         params={"offset": son + 1, "timeout": 5}, timeout=15)
        r.raise_for_status()
        gs = r.json().get("result", [])
        if gs: tg_offset_kaydet(gs[-1]["update_id"])
        return gs
    except Exception: return []

def _dinle():
    bilgi("telegram", "📱 Telegram dinleniyor...")
    mesaj_gonder(
        "🟢 <b>NEXUS v6</b> çevrimiçi!\n"
        "20 bot aktif | Kategori öğrenme başladı\n"
        "/yardim ile komutları gör."
    )
    while not _dur.is_set():
        try:
            for g in _guncelleme():
                msg = g.get("message", {})
                metin = msg.get("text", "")
                cid   = str(msg.get("chat", {}).get("id", ""))
                simdi = time.monotonic()
                if metin and cid:
                    if simdi - _flood.get(cid, 0) >= FLOOD_LIMIT:
                        _flood[cid] = simdi
                        cevap = _isle(metin, cid)
                        if cevap: mesaj_gonder(cevap, cid)
            _dur.wait(2)
        except Exception as e:
            hata("telegram", f"Dongu: {e}"); _dur.wait(5)

def arkaplanda_baslat() -> threading.Thread:
    global _thread
    if _thread and _thread.is_alive(): return _thread
    _dur.clear()
    _thread = threading.Thread(target=_dinle, daemon=True, name="nexus-telegram")
    _thread.start()
    return _thread

def durdur():
    _dur.set()
    if _thread: _thread.join(timeout=5)
    bilgi("telegram", "Telegram durduruldu")
