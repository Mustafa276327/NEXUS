#!/usr/bin/env python3
"""NEXUS v6 - Web Panel (kimlik doğrulamalı)"""
import json, os, sys, threading, sqlite3
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, parse_qs

BASE = Path(__file__).parent.parent
sys.path.insert(0, str(BASE))
os.environ.setdefault("NEXUS_BASE", str(BASE))

_env = BASE / ".env"
if _env.exists():
    for s in _env.read_text(encoding="utf-8").splitlines():
        s = s.strip()
        if s and not s.startswith("#") and "=" in s:
            k, v = s.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip())

WEB_PORT  = int(os.environ.get("NEXUS_PORT", "8080"))
WEB_SIFRE = os.environ.get("WEB_SIFRE", "nexus123")
DB        = str(BASE / "depo" / "nexus.db")
KAYIT     = BASE / "kayit"

def _db(sql, params=()):
    try:
        if not Path(DB).exists(): return []
        con = sqlite3.connect(DB, timeout=5)
        con.row_factory = sqlite3.Row
        r = [dict(x) for x in con.execute(sql, params).fetchall()]
        con.close(); return r
    except Exception: return []

def _j(v): return json.dumps(v, ensure_ascii=False, default=str)

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def _send(self, veri, kod=200, tip="application/json"):
        body = veri if isinstance(veri, bytes) else veri.encode()
        self.send_response(kod)
        self.send_header("Content-Type", f"{tip}; charset=utf-8")
        self.send_header("Content-Length", len(body))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _auth(self) -> bool:
        t = self.headers.get("X-Auth-Token","")
        qs = parse_qs(urlparse(self.path).query)
        return (t or qs.get("token",[""])[0]) == WEB_SIFRE

    def do_GET(self):
        yol = urlparse(self.path).path
        qs  = parse_qs(urlparse(self.path).query)
        if yol in ("/","/index.html"):
            try:
                self._send((BASE/"panel"/"index.html").read_bytes(), tip="text/html")
            except Exception:
                self._send(b"<h1>NEXUS v6</h1>", tip="text/html")
            return
        if not self._auth():
            self._send(_j({"hata":"Yetkisiz — token gerekli"}), 401); return
        api = {
            "/api/durum":    self._durum,
            "/api/botlar":   self._botlar,
            "/api/bilgi":    self._bilgi,
            "/api/kararlar": self._kararlar,
            "/api/gorevler": self._gorevler,
            "/api/beceriler":self._beceriler,
            "/api/metrikler":self._metrikler,
            "/api/flags":    self._flags,
            "/api/loglar":   lambda: self._loglar(qs),
            "/health":       lambda: {"ok": True, "versiyon": "6.0.0"},
        }
        fn = api.get(yol)
        if fn:
            try: self._send(_j(fn()))
            except Exception as e: self._send(_j({"hata": str(e)}), 500)
        else:
            self._send(_j({"hata":"404"}), 404)

    def do_POST(self):
        if not self._auth():
            self._send(_j({"hata":"Yetkisiz"}), 401); return
        yol = urlparse(self.path).path
        n = int(self.headers.get("Content-Length",0))
        try: body = json.loads(self.rfile.read(n) or b"{}")
        except Exception: body = {}
        try:
            if yol == "/api/flag":
                from beyin.feature_flags import toggle
                toggle(body.get("flag",""), body.get("deger","false") in (True,"true","on"))
                self._send(_j({"ok": True}))
            elif yol == "/api/telegram":
                from telegram.bot import mesaj_gonder
                mesaj_gonder(body.get("mesaj",""))
                self._send(_j({"ok": True}))
            elif yol == "/api/yedek":
                from sistem.yedekleme import yedek_al
                threading.Thread(target=yedek_al, daemon=True).start()
                self._send(_j({"ok": True}))
            elif yol == "/api/ogren":
                from beyin.ogretici import hibrit_ogren, _aktif_kategori
                konu = body.get("konu","Python")
                threading.Thread(target=hibrit_ogren, args=(konu, _aktif_kategori), daemon=True).start()
                self._send(_j({"ok": True}))
            else:
                self._send(_j({"hata":"404"}), 404)
        except Exception as e:
            self._send(_j({"ok": False, "hata": str(e)}), 500)

    def _durum(self):
        try:
            from sistem.telefon import sistem_durumu
            return sistem_durumu()
        except Exception:
            return {"pil_yuzde":50,"sarj":False,"wifi":False,"ssid":"","sicaklik":35}

    def _botlar(self):
        return _db("SELECT isim,rutbe,uzmanlik,profesyonellik_puani,aktif FROM botlar ORDER BY profesyonellik_puani DESC")

    def _bilgi(self):
        kats = _db("SELECT kategori,COUNT(*) as sayi FROM bilgi_bankasi GROUP BY kategori ORDER BY sayi DESC")
        son  = _db("SELECT konu,kategori,kaynak,tarih FROM bilgi_bankasi ORDER BY id DESC LIMIT 30")
        return {"kategoriler": kats, "son": son,
                "toplam": _db("SELECT COUNT(*) as n FROM bilgi_bankasi")[0]["n"] if _db("SELECT COUNT(*) as n FROM bilgi_bankasi") else 0}

    def _kararlar(self):
        return _db("SELECT karar,oylama_sonucu,tarih FROM kararlar ORDER BY id DESC LIMIT 20")

    def _gorevler(self):
        return {
            "bekleyen":   _db("SELECT baslik,kategori,zorluk FROM uretilen_gorevler WHERE durum='bekliyor' ORDER BY id DESC LIMIT 10"),
            "tamamlanan": _db("SELECT baslik,puan,tamamlanma FROM uretilen_gorevler WHERE durum='tamamlandi' ORDER BY id DESC LIMIT 10"),
            "kuyruk":     _db("SELECT COUNT(*) as n FROM veri_kuyruğu WHERE islendi=0")[0]["n"] if _db("SELECT COUNT(*) as n FROM veri_kuyruğu WHERE islendi=0") else 0,
        }

    def _beceriler(self):
        return _db("SELECT isim,puan,kullanim_sayisi,kategori FROM beceri_kutuphanesi ORDER BY puan DESC LIMIT 20")

    def _metrikler(self):
        try:
            from beyin.circuit_breaker import tum_metrikler
            from beyin.logger import dusurülen_sayisi
            from beyin.geri_bildirim import ortalama_puan, gelisim_trendi
            return {
                "circuit_breakers": tum_metrikler(),
                "log_dusurülen": dusurülen_sayisi(),
                "ortalama_puan": ortalama_puan(),
                "trend": gelisim_trendi(),
            }
        except Exception as e: return {"hata": str(e)}

    def _flags(self):
        try:
            from beyin.feature_flags import tumu
            return tumu()
        except Exception: return {}

    def _loglar(self, qs):
        try:
            log_d = KAYIT / "nexus.log"
            if not log_d.exists(): return {"loglar":[],"toplam":0}
            satirlar = log_d.read_text(encoding="utf-8",errors="ignore").splitlines()[-300:]
            loglar = []
            for s in satirlar:
                if not s.strip(): continue
                try: loglar.append(json.loads(s))
                except Exception: loglar.append({"msg": s.strip()})
            son_id = int(qs.get("son_id",[0])[0])
            return {"loglar": loglar[son_id:], "toplam": len(loglar)}
        except Exception as e: return {"loglar":[],"toplam":0,"hata":str(e)}

def main():
    s = HTTPServer(("0.0.0.0", WEB_PORT), H)
    print(f"🌐 NEXUS v6 Panel → http://0.0.0.0:{WEB_PORT}?token={WEB_SIFRE}")
    try: s.serve_forever()
    except KeyboardInterrupt: s.shutdown()

if __name__ == "__main__":
    main()
