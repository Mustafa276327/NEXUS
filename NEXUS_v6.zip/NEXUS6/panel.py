#!/usr/bin/env python3
"""NEXUS v6 - Termux Ana Panel (Enter=geri, Ctrl+C yok)"""
import os, sys, subprocess, time, sqlite3, json, signal
from pathlib import Path
from datetime import datetime

BASE = Path(__file__).parent.absolute()
sys.path.insert(0, str(BASE))
os.environ["NEXUS_BASE"] = str(BASE)

_env = BASE / ".env"
if _env.exists():
    for s in _env.read_text(encoding="utf-8").splitlines():
        s = s.strip()
        if s and not s.startswith("#") and "=" in s:
            k, v = s.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip())

DB    = BASE / "depo" / "nexus.db"
KAYIT = BASE / "kayit"
PORT  = os.environ.get("NEXUS_PORT", "8080")
SIFRE = os.environ.get("WEB_SIFRE", "nexus123")
BOT_PID = BASE / "depo" / "bot.pid"
WEB_PID = BASE / "depo" / "web.pid"

R = {"S":"\033[0m","K":"\033[1m","KO":"\033[2m","M":"\033[91m",
     "Y":"\033[92m","SA":"\033[93m","B":"\033[94m","C":"\033[96m"}

def rk(t, r): return f"{R.get(r,'')}{t}{R['S']}"
def temizle(): os.system("clear")

def db(sql, params=()):
    try:
        if not DB.exists(): return []
        con = sqlite3.connect(str(DB), timeout=5)
        con.row_factory = sqlite3.Row
        r = [dict(x) for x in con.execute(sql, params).fetchall()]
        con.close(); return r
    except Exception: return []

def db1(sql, params=()):
    r = db(sql, params); return r[0] if r else {}

def _pid_oku(d):
    try: return int(d.read_text().strip())
    except Exception: return None

def _calisiyor(pid):
    if not pid: return False
    try: os.kill(pid, 0); return True
    except (OSError, ProcessLookupError): return False

def bot_ok(): return _calisiyor(_pid_oku(BOT_PID))
def web_ok(): return _calisiyor(_pid_oku(WEB_PID))
def dur_ikon(a): return rk("● Çalışıyor", "Y") if a else rk("○ Durdu   ", "KO")

def botu_baslat():
    if bot_ok(): print(rk("  ⚠️  Bot zaten çalışıyor!", "SA")); return
    KAYIT.mkdir(parents=True, exist_ok=True)
    (BASE/"depo").mkdir(parents=True, exist_ok=True)
    try:
        env = {**os.environ, "NEXUS_BASE": str(BASE)}
        p = subprocess.Popen(
            [sys.executable, str(BASE/"beyin"/"ana_bot.py")],
            cwd=str(BASE), env=env,
            stdout=open(str(KAYIT/"nexus.log"), "a"),
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        BOT_PID.write_text(str(p.pid))
        time.sleep(2)
        if _calisiyor(p.pid):
            print(rk(f"  ✅ Bot başlatıldı (PID:{p.pid})", "Y"))
        else:
            print(rk("  ❌ Bot hemen kapandı — log kontrol et", "M"))
    except Exception as e: print(rk(f"  ❌ {e}", "M"))

def webi_baslat():
    if web_ok(): print(rk("  ⚠️  Web panel zaten çalışıyor!", "SA")); return
    try:
        env = {**os.environ, "NEXUS_BASE": str(BASE)}
        p = subprocess.Popen(
            [sys.executable, str(BASE/"panel"/"server.py")],
            cwd=str(BASE), env=env,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        WEB_PID.write_text(str(p.pid))
        time.sleep(1)
        try:
            r = subprocess.run(["termux-wifi-connectioninfo"], capture_output=True, text=True, timeout=5)
            ip = json.loads(r.stdout).get("ip","localhost")
        except Exception: ip = "localhost"
        if _calisiyor(p.pid):
            print(rk(f"  ✅ Web: http://{ip}:{PORT}?token={SIFRE}", "Y"))
        else:
            print(rk("  ❌ Web panel başlamadı", "M"))
    except Exception as e: print(rk(f"  ❌ {e}", "M"))

def hepsini_baslat():
    print(rk("\n  🚀 Başlatılıyor...\n", "C"))
    botu_baslat(); time.sleep(3); webi_baslat(); print()

def _durdur_pid(d, isim):
    pid = _pid_oku(d)
    if not pid: print(rk(f"  ⚠️  {isim} zaten durmuş", "KO")); return
    if _calisiyor(pid):
        try:
            os.kill(pid, signal.SIGTERM)
            for _ in range(10):
                if not _calisiyor(pid): break
                time.sleep(0.5)
            if _calisiyor(pid): os.kill(pid, signal.SIGKILL)
            print(rk(f"  ✅ {isim} durduruldu", "Y"))
        except Exception as e: print(rk(f"  ⚠️ {e}", "SA"))
    else: print(rk(f"  ⚠️  {isim} zaten durmuş", "KO"))
    try: d.unlink()
    except Exception: pass

def hepsini_durdur():
    print(rk("\n  ⏹️  Durduruluyor...\n", "SA"))
    _durdur_pid(BOT_PID, "Bot"); _durdur_pid(WEB_PID, "Web Panel"); print()

SEVIYE_RENK = {"HATA":"M","UYARI":"SA","BASARI":"Y","BILGI":"B","ANAYZ":"C"}

def _log_satirlari(filtre=None, limit=40):
    lf = KAYIT / "nexus.log"
    if not lf.exists(): return []
    satirlar = lf.read_text(encoding="utf-8", errors="ignore").splitlines()
    sonuc = []
    for s in reversed(satirlar):
        if not s.strip(): continue
        try:
            d = json.loads(s)
            sev = d.get("level","BILGI"); mod = d.get("module","?")
            msg = d.get("msg",""); z = d.get("ts","")[-8:] if d.get("ts") else ""
        except Exception:
            import re
            m = re.match(r'\[(\w+)\s*\]\s*(\d{2}:\d{2}:\d{2})\s*\[([^\]]+)\]\s*(.*)', s)
            if m: sev,z,mod,msg = m.group(1),m.group(2),m.group(3),m.group(4)
            else: sev,z,mod,msg = "BILGI","","?",s[:100]
        if filtre == "bot" and "bot" not in mod.lower(): continue
        if filtre == "hata" and sev != "HATA": continue
        if filtre == "dusunce" and mod != "ana_bot" and "ic_ses" not in msg: continue
        sonuc.append((sev, z, mod, msg[:80]))
        if len(sonuc) >= limit: break
    return list(reversed(sonuc))

def _log_yazdir(s):
    if not s: print(rk("  (Log yok)", "KO")); return
    for sev, z, mod, msg in s:
        renk = SEVIYE_RENK.get(sev,"B")
        print(rk(f"  {z}","KO")+" "+rk(f"[{sev[:5]:<5}]",renk)+" "+rk(f"[{mod[:12]:<12}]","C")+" "+msg)

def ana_menu():
    temizle()
    bot_d = dur_ikon(bot_ok()); web_d = dur_ikon(web_ok())
    bilgi_n = db1("SELECT COUNT(*) as n FROM bilgi_bankasi").get("n",0)
    bot_n   = db1("SELECT COUNT(*) as n FROM botlar WHERE aktif=1").get("n",0)
    gorev_n = db1("SELECT COUNT(*) as n FROM uretilen_gorevler WHERE durum='tamamlandi'").get("n",0)
    kuyrukt = db1("SELECT COUNT(*) as n FROM veri_kuyruğu WHERE islendi=0").get("n",0)
    print(rk("╔══════════════════════════════════════════════╗","C"))
    print(rk("║    ⚡  N E X U S  v6  —  ANA PANEL  ⚡       ║","K"))
    print(rk("╠══════════════════════════════════════════════╣","C"))
    print(rk("║","C")+f"  🤖 Bot: {bot_d}  |  🌐 Web: {web_d}           "+rk("║","C"))
    print(rk("║","C")+f"  📚 {bilgi_n} bilgi  🤖 {bot_n} bot  ✅ {gorev_n} görev  ⏳ {kuyrukt}       "+rk("║","C"))
    print(rk("╠══════════════════════════════════════════════╣","C"))
    menu = [
        ("1","🚀 Başlat    (Bot + Web Panel)"),
        ("2","⏹️  Durdur    (Hepsini)"),
        ("3","📜 Loglar"),
        ("4","📊 Sistem Durumu"),
        ("5","🤖 Botlar"),
        ("6","📚 Öğrenilen Bilgiler"),
        ("7","📱 Telefon Durumu"),
        ("8","🚪 Çıkış     (Bot çalışmaya devam eder)"),
    ]
    for k, v in menu:
        print(rk("║","C")+f"  [{rk(k,'SA')}] {v:<43}"+rk("║","C"))
    print(rk("╚══════════════════════════════════════════════╝","C"))
    return input(rk("\n  » Seçim: ","K")).strip()

def log_menusu():
    while True:
        temizle()
        print(rk("\n  📜 LOG MENÜsÜ\n","C"))
        print(f"  [{rk('1','SA')}] Sistem Logları")
        print(f"  [{rk('2','SA')}] Bot Logları")
        print(f"  [{rk('3','SA')}] Hata Logları")
        print(f"  [{rk('4','SA')}] Düşünce Logları (İç Ses)")
        print(f"  [{rk('0','KO')}] Geri")
        s = input(rk("\n  » Seçim: ","K")).strip()
        if s == "0": break
        temizle()
        basliklar = {"1":"Sistem Logları","2":"Bot Logları","3":"Hata Logları","4":"Düşünce Logları"}
        filtreler = {"1":None,"2":"bot","3":"hata","4":"dusunce"}
        print(rk(f"\n  📜 {basliklar.get(s,'?')} — Son 40 kayıt\n","C"))
        if s == "4":
            ic = BASE/"docs"/"ic_ses.txt"
            if ic.exists(): print(rk(ic.read_text(encoding="utf-8")[-3000:],"C"))
            else: print(rk("  Henüz iç ses kaydı yok.","KO"))
        elif s in filtreler:
            _log_yazdir(_log_satirlari(filtre=filtreler[s]))
        input(rk("\n\n  [Enter = geri]","KO"))

def sistem_durumu_menu():
    print(rk("\n  📊 SİSTEM — Her 8sn güncellenir\n","C"))
    import threading
    _dur = threading.Event()
    def _dongu():
        while not _dur.is_set():
            temizle()
            print(rk(f"  📊 SİSTEM  {datetime.now().strftime('%H:%M:%S')}\n","C"))
            print(rk("  ── Servisler ─────────────────────────","B"))
            print(f"  🤖 Ana Bot    : {dur_ikon(bot_ok())}")
            print(f"  🌐 Web Panel  : {dur_ikon(web_ok())}")
            print(rk("\n  ── Veritabanı ────────────────────────","B"))
            b_n = db1("SELECT COUNT(*) as n FROM bilgi_bankasi").get("n",0)
            bt_n= db1("SELECT COUNT(*) as n FROM botlar WHERE aktif=1").get("n",0)
            g_n = db1("SELECT COUNT(*) as n FROM uretilen_gorevler WHERE durum='tamamlandi'").get("n",0)
            bc_n= db1("SELECT COUNT(*) as n FROM beceri_kutuphanesi").get("n",0)
            k_n = db1("SELECT COUNT(*) as n FROM veri_kuyruğu WHERE islendi=0").get("n",0)
            print(f"  📚 Bilgi Bankası   : {b_n}")
            print(f"  💾 Beceri          : {bc_n}")
            print(f"  ✅ Görev           : {g_n}")
            print(f"  🤖 Bot             : {bt_n}")
            print(f"  ⏳ Kuyruk          : {k_n} bekliyor")
            son = db("SELECT konu,kategori FROM bilgi_bankasi ORDER BY id DESC LIMIT 3")
            if son:
                print(rk("\n  ── Son Öğrenilenler ──────────────────","B"))
                for x in son: print(f"  • [{x['kategori']}] {x['konu'][:50]}")
            lf = KAYIT/"nexus.log"
            if lf.exists(): print(f"\n  📜 Log: {lf.stat().st_size/1024:.1f} KB")
            print(rk("\n  [Enter = geri]","KO"))
            _dur.wait(8)
    t = threading.Thread(target=_dongu, daemon=True)
    t.start()
    input()
    _dur.set(); t.join(timeout=2)

def botlar_menusu():
    temizle()
    print(rk("\n  🤖 BOT LİSTESİ\n","C"))
    botlar = db("SELECT isim,rutbe,uzmanlik,profesyonellik_puani,aktif FROM botlar ORDER BY profesyonellik_puani DESC")
    if not botlar: print(rk("  Henüz dinamik bot yok.","KO"))
    else:
        print(rk(f"  {'#':<3} {'İSİM':<18} {'RÜTBE':<11} {'UZMANLIK':<18} {'PUAN':>5} DURUM","B"))
        print("  "+"─"*65)
        for i, b in enumerate(botlar, 1):
            dur = rk("✅","Y") if b["aktif"] else rk("○","KO")
            print(f"  {i:<3} {b['isim'][:18]:<18} {b['rutbe'][:11]:<11} "
                  f"{(b['uzmanlik'] or '-')[:18]:<18} {b['profesyonellik_puani']:>5.0f} {dur}")
    input(rk("\n  [Enter = geri]","KO"))

def bilgiler_menusu():
    temizle()
    print(rk("\n  📚 ÖĞRENILEN BİLGİLER\n","C"))
    toplam = db1("SELECT COUNT(*) as n FROM bilgi_bankasi").get("n",0)
    print(rk(f"  Toplam: {toplam} bilgi\n","SA"))
    kats = db("SELECT kategori,COUNT(*) as n FROM bilgi_bankasi GROUP BY kategori ORDER BY n DESC")
    if kats:
        maks = max(k["n"] for k in kats)
        for k in kats:
            bar = "█" * max(1, int(k["n"]/maks*20))
            print(f"  {(k['kategori'] or 'Genel')[:15]:<15} {rk(bar,'Y')} {rk(str(k['n']),'SA')}")
    print(rk("\n  ── Son 10 ──────────────────────────────","B"))
    son = db("SELECT konu,kategori,tarih FROM bilgi_bankasi ORDER BY id DESC LIMIT 10")
    for b in son:
        tarih = b["tarih"][:16] if b.get("tarih") else ""
        print(f"  {rk('▸','C')} {b['konu'][:45]:<45} {rk(tarih,'KO')}")
    input(rk("\n  [Enter = geri]","KO"))

def telefon_menusu():
    import threading
    print(rk("\n  📱 TELEFON — Her 5sn güncellenir\n","C"))
    _dur = threading.Event()
    def _dongu():
        while not _dur.is_set():
            temizle()
            print(rk(f"  📱 TELEFON  {datetime.now().strftime('%H:%M:%S')}\n","C"))
            try:
                import json as _j
                r = subprocess.run(["termux-battery-status"], capture_output=True, text=True, timeout=5)
                d = _j.loads(r.stdout)
                pil = d.get("percentage", d.get("level","?")); sarj = d.get("status","")
                print(rk("  ── Güç ────────────────────────────────","B"))
                pr = "Y" if pil >= 50 else "SA" if pil >= 20 else "M"
                print(f"  🔋 Pil          : {rk(f'%{pil}',pr)} {'🔌 Şarj' if sarj in ('CHARGING','FULL') else ''}")
                print(f"  🌡️  Sıcaklık     : {d.get('temperature','?')}°C")
                print(f"  ⚡ Voltaj        : {d.get('voltage',0)/1000:.2f}V")
                print(f"  ❤️  Sağlık        : {d.get('health','?')}")
            except Exception as e: print(rk(f"  Batarya: {e}","KO"))
            try:
                r2 = subprocess.run(["termux-wifi-connectioninfo"], capture_output=True, text=True, timeout=5)
                w = _j.loads(r2.stdout)
                print(rk("\n  ── WiFi ───────────────────────────────","B"))
                print(f"  📶 SSID          : {w.get('ssid','?')}")
                print(f"  🌐 IP            : {w.get('ip','?')}")
                print(f"  📡 Sinyal        : {w.get('rssi','?')} dBm")
                print(f"  🚀 Hız           : {w.get('link_speed_mbps','?')} Mbps")
            except Exception: pass
            try:
                r3 = subprocess.run(["free","-h"], capture_output=True, text=True, timeout=5)
                print(rk("\n  ── Bellek ─────────────────────────────","B"))
                for satir in r3.stdout.splitlines():
                    if "Mem:" in satir:
                        p = satir.split()
                        print(f"  💾 Toplam  : {p[1] if len(p)>1 else '?'}  Kullanım: {p[2] if len(p)>2 else '?'}  Boş: {p[3] if len(p)>3 else '?'}")
            except Exception: pass
            try:
                r4 = subprocess.run(["df","-h","/data"], capture_output=True, text=True, timeout=5)
                print(rk("\n  ── Depolama ───────────────────────────","B"))
                for satir in r4.stdout.splitlines()[1:]:
                    p = satir.split()
                    if len(p) >= 5:
                        print(f"  💿 Toplam: {p[1]}  Kullanılan: {p[2]} ({p[4]})  Boş: {p[3]}")
            except Exception: pass
            print(rk("\n  [Enter = geri]","KO"))
            _dur.wait(5)
    t = threading.Thread(target=_dongu, daemon=True)
    t.start()
    input()
    _dur.set(); t.join(timeout=2)

def main():
    if not (BASE/"beyin"/"ana_bot.py").exists():
        print("❌ NEXUS_FINAL klasöründen çalıştır!\n   cd ~/NEXUS && python panel.py")
        sys.exit(1)
    (BASE/"depo").mkdir(parents=True, exist_ok=True)
    KAYIT.mkdir(parents=True, exist_ok=True)
    while True:
        secim = ana_menu()
        if secim == "1":
            hepsini_baslat()
            input(rk("  [Enter = menü]","KO"))
        elif secim == "2":
            hepsini_durdur()
            input(rk("  [Enter = menü]","KO"))
        elif secim == "3":
            log_menusu()
        elif secim == "4":
            sistem_durumu_menu()
        elif secim == "5":
            botlar_menusu()
        elif secim == "6":
            bilgiler_menusu()
        elif secim == "7":
            telefon_menusu()
        elif secim == "8":
            temizle()
            if bot_ok():
                pid = _pid_oku(BOT_PID)
                print(rk(f"\n  ✅ Bot arka planda: PID {pid}","Y"))
                print(rk("  Durdurmak: python panel.py → [2]\n","KO"))
            else:
                print(rk("\n  Bot zaten durmuş.\n","KO"))
            sys.exit(0)

if __name__ == "__main__":
    main()
